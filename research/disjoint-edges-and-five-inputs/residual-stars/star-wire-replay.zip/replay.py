"""Verify bundled research sources with Lean 4.36.0, the saved LRAT witnesses and built project imports."""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project',required=True,type=Path,help='prebuilt PequalNP lean directory')
    parser.add_argument('--toolchain',required=True,type=Path,help='directory containing Lean 4.36.0 bin')
    parser.add_argument('--build-dir',required=True,type=Path,help='new build directory')
    parser.add_argument('--prebuilt',action='append',default=[],type=Path,help='additional import directory')
    parser.add_argument('--reuse-prerequisites',action='store_true',help='reuse bundled prerequisite modules found in prebuilt directories')
    parser.add_argument('--resume',action='store_true',help='reuse hash-verified successful objects from this manifest in the build directory')
    parser.add_argument('--check-objects',action='store_true',help='also run leanchecker on the selected conclusions')
    parser.add_argument('--target',action='append',default=[],help='check a named module and its dependencies')
    parser.add_argument('--time-limit',type=float,default=None,help='maximum total wall time in seconds')
    args=parser.parse_args()
    here=Path(__file__).resolve().parent
    manifest=json.loads((here/'modules.json').read_text(encoding='utf8'))
    end=time.monotonic()+args.time_limit if args.time_limit else None
    project=args.project.resolve()
    binary=args.toolchain.resolve()/'bin'
    work=args.build_dir.resolve()
    work.mkdir(parents=True,exist_ok=args.resume)
    (work/'certificates').mkdir(exist_ok=args.resume)
    dirs=[p.resolve() for p in args.prebuilt]
    libs=[project/'.lake/build/lib/lean',*sorted((project/'.lake/packages').glob('*/.lake/build/lib/lean'))]
    env=dict(os.environ,LEAN_PATH=os.pathsep.join(map(str,[work,*dirs,*libs])),LEAN_NUM_THREADS='1',SIX_CERT_GENERATE='0')
    def execute(cmd,capture=False):
        remaining=None if end is None else end-time.monotonic()
        if remaining is not None and remaining<=0:raise TimeoutError('Replay budget exhausted')
        return subprocess.run(cmd,env=env,cwd=work,check=True,timeout=remaining,capture_output=capture,text=capture)
    version=execute([binary/'lean','--version'],True).stdout.strip()
    if not version.startswith('Lean (version 4.36.0,'):raise SystemExit(version)
    print(version,flush=True)
    mods=manifest['modules']
    context=sha256((here/'modules.json').read_bytes()).hexdigest()
    def verified(rel,checksum):
        data=(here/rel).read_bytes()
        if sha256(data).hexdigest()!=checksum:raise ValueError('Hash mismatch for '+rel)
        return data
    for rec in mods.values():
        verified(rec['source'],rec['sha256'])
        if 'lrat' in rec:verified(rec['lrat'],rec['lrat_sha256'])
    seen=set()
    def build(name):
        if name in seen:return
        seen.add(name)
        rec=mods[name]
        if rec['source'].startswith('prerequisites/') and args.reuse_prerequisites and any((p/(name+'.olean')).exists() for p in dirs):
            return
        for dep in rec['imports']:build(dep)
        obj=work/(name+'.olean')
        stamp=work/(name+'.checked.json')
        def receipt():
            return dict(manifest=context,lean=version,source=rec['sha256'],certificate=rec.get('lrat_sha256'),
                        object=sha256(obj.read_bytes()).hexdigest())
        if args.resume and obj.is_file() and stamp.is_file() and json.loads(stamp.read_text(encoding='utf8'))==receipt():
            print('Verified checkpoint',name,flush=True)
            return
        source=work/(name+'.lean')
        shutil.copyfile(here/rec['source'],source)
        if 'lrat' in rec:shutil.copyfile(here/rec['lrat'],work/'certificates'/(name+'.lrat'))
        print('Checking',name,flush=True)
        execute([binary/'lean','-j','1','-M','6000','-R',work,'-o',obj,source])
        stamp.write_text(json.dumps(receipt())+'\n',encoding='utf8')
    choices=args.target or manifest['targets']
    for name in choices:build(name)
    if args.check_objects:
        for name in choices:execute([binary/'leanchecker','-v',name])
    print('Verified '+', '.join(choices),flush=True)
if __name__=='__main__':main()
