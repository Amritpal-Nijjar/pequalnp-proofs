import Mathlib.Tactic
import Mathlib.Data.Sym.Sym2
namespace EdgeCensus
variable {α : Type*} [DecidableEq α]
/-- The only graph templates needed to extend two disjoint residual edges to
    four distinct simple edges. Each field is discharged from the circuit below. -/
structure Forbidden (U : Finset (Sym2 α)) : Prop where
  loop : ∀ x, s(x,x)∉U
  triangle : ∀ a b c : α, [a,b,c].Nodup → s(a,b)∈U → s(b,c)∈U → s(c,a)∈U → False
  square : ∀ a b c d : α, [a,b,c,d].Nodup → s(a,b)∈U → s(b,c)∈U → s(c,d)∈U → s(d,a)∈U → False
  matching : ∀ a b c d e f : α, [a,b,c,d,e,f].Nodup → s(a,b)∈U → s(c,d)∈U → s(e,f)∈U → False
  path : ∀ a b c d e : α, [a,b,c,d,e].Nodup → s(a,b)∈U → s(b,c)∈U → s(c,d)∈U → s(d,e)∈U → False
  fork : ∀ a b c d e : α, [a,b,c,d,e].Nodup → s(a,b)∈U → s(a,c)∈U → s(a,d)∈U → s(d,e)∈U → False
  twoStars : ∀ a b c d e f : α, [a,b,c,d,e,f].Nodup → s(a,b)∈U → s(a,c)∈U → s(d,e)∈U → s(d,f)∈U → False
  threeStar : ∀ a b c d e f : α, [a,b,c,d,e,f].Nodup → s(a,b)∈U → s(a,c)∈U → s(a,e)∈U → s(d,f)∈U → False

theorem more {U : Finset (Sym2 α)} (card : U.card=4) (a b c : Sym2 α) :
    ∃ x y : α, s(x,y)∈U ∧ s(x,y)≠a ∧ s(x,y)≠b ∧ s(x,y)≠c := by
  classical
  let K : Finset (Sym2 α) := {a,b,c}
  have cap : K.card≤3 := by
    have t := Finset.card_insert_le a ({b,c} : Finset (Sym2 α))
    have u := Finset.card_insert_le b ({c} : Finset (Sym2 α))
    simp only [Finset.card_singleton] at u
    dsimp [K]; omega
  have omitted : ∃ e∈U, e∉K := by
    by_contra! all
    have sub : U⊆K := fun x hx => all x hx
    have bound := Finset.card_le_card sub; omega
  obtain ⟨e,mem,out⟩ := omitted
  induction e using Sym2.ind with
  | h x y =>
    exact ⟨x,y,mem,fun eq => out (by simp [K,eq]),fun eq => out (by simp [K,eq]),fun eq => out (by simp [K,eq])⟩

private theorem rev {U : Finset (Sym2 α)} {a b : α} (h : s(a,b)∈U) : s(b,a)∈U := Sym2.eq_swap ▸ h

theorem extendPath {U : Finset (Sym2 α)} (F : Forbidden U) (card : U.card=4) (a b c d : α)
    (nd : [a,b,c,d].Nodup) (r0 : s(a,b)∈U) (r1 : s(b,c)∈U) (r2 : s(c,d)∈U) : False := by
  classical
  obtain ⟨x,y,last,n0,n1,n2⟩ := more card s(a,b) s(b,c) s(c,d)
  have xy : x≠y := by rintro rfl; exact F.loop _ last
  simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or] at nd
  have v0 := rev r0
  have v1 := rev r1
  have v2 := rev r2
  have vLast := rev last
  by_cases ex : x=a
  · subst x
    by_cases ey : y=a
    · subst y
      exact F.loop _ last
    by_cases ey : y=b
    · subst y
      exact n0 rfl
    by_cases ey : y=c
    · subst y
      exact F.triangle a b c (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 r1 vLast
    by_cases ey : y=d
    · subst y
      exact F.square a b c d (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 r1 r2 vLast
    exact F.path d c b a y (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) v2 v1 v0 last
  by_cases ex : x=b
  · subst x
    by_cases ey : y=a
    · subst y
      exact n0 (Sym2.eq_swap ..)
    by_cases ey : y=b
    · subst y
      exact F.loop _ last
    by_cases ey : y=c
    · subst y
      exact n1 rfl
    by_cases ey : y=d
    · subst y
      exact F.triangle b c d (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r1 r2 vLast
    exact F.fork b a y c d (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) v0 last r1 r2
  by_cases ex : x=c
  · subst x
    by_cases ey : y=a
    · subst y
      exact F.triangle a b c (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 r1 last
    by_cases ey : y=b
    · subst y
      exact n1 (Sym2.eq_swap ..)
    by_cases ey : y=c
    · subst y
      exact F.loop _ last
    by_cases ey : y=d
    · subst y
      exact n2 rfl
    exact F.fork c d y b a (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r2 last v1 v0
  by_cases ex : x=d
  · subst x
    by_cases ey : y=a
    · subst y
      exact F.square a b c d (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 r1 r2 last
    by_cases ey : y=b
    · subst y
      exact F.triangle b c d (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r1 r2 last
    by_cases ey : y=c
    · subst y
      exact n2 (Sym2.eq_swap ..)
    by_cases ey : y=d
    · subst y
      exact F.loop _ last
    exact F.path a b c d y (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 r1 r2 last
  by_cases ey : y=a
  · subst y
    exact F.path d c b a x (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) v2 v1 v0 vLast
  by_cases ey : y=b
  · subst y
    exact F.fork b a x c d (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) v0 vLast r1 r2
  by_cases ey : y=c
  · subst y
    exact F.fork c d x b a (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r2 vLast v1 v0
  by_cases ey : y=d
  · subst y
    exact F.path a b c d x (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 r1 r2 vLast
  exact F.matching a b c d x y (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 r2 last

theorem extendStar {U : Finset (Sym2 α)} (F : Forbidden U) (card : U.card=4) (a b c d e : α)
    (nd : [a,b,c,d,e].Nodup) (r0 : s(a,b)∈U) (r1 : s(a,c)∈U) (r2 : s(d,e)∈U) : False := by
  classical
  obtain ⟨x,y,last,n0,n1,n2⟩ := more card s(a,b) s(a,c) s(d,e)
  have xy : x≠y := by rintro rfl; exact F.loop _ last
  simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or] at nd
  have v0 := rev r0
  have v1 := rev r1
  have v2 := rev r2
  have vLast := rev last
  by_cases ex : x=a
  · subst x
    by_cases ey : y=a
    · subst y
      exact F.loop _ last
    by_cases ey : y=b
    · subst y
      exact n0 rfl
    by_cases ey : y=c
    · subst y
      exact n1 rfl
    by_cases ey : y=d
    · subst y
      exact F.fork a b c d e (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 r1 last r2
    by_cases ey : y=e
    · subst y
      exact F.fork a b c e d (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 r1 last v2
    exact F.threeStar a b c d y e (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 r1 last r2
  by_cases ex : x=b
  · subst x
    by_cases ey : y=a
    · subst y
      exact n0 (Sym2.eq_swap ..)
    by_cases ey : y=b
    · subst y
      exact F.loop _ last
    by_cases ey : y=c
    · subst y
      exact F.triangle a b c (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 last v1
    by_cases ey : y=d
    · subst y
      exact F.path c a b d e (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) v1 r0 last r2
    by_cases ey : y=e
    · subst y
      exact F.path c a b e d (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) v1 r0 last v2
    exact F.matching a c b y d e (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r1 last r2
  by_cases ex : x=c
  · subst x
    by_cases ey : y=a
    · subst y
      exact n1 (Sym2.eq_swap ..)
    by_cases ey : y=b
    · subst y
      exact F.triangle a b c (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 vLast v1
    by_cases ey : y=c
    · subst y
      exact F.loop _ last
    by_cases ey : y=d
    · subst y
      exact F.path b a c d e (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) v0 r1 last r2
    by_cases ey : y=e
    · subst y
      exact F.path b a c e d (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) v0 r1 last v2
    exact F.matching a b c y d e (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 last r2
  by_cases ex : x=d
  · subst x
    by_cases ey : y=a
    · subst y
      exact F.fork a b c d e (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 r1 vLast r2
    by_cases ey : y=b
    · subst y
      exact F.path c a b d e (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) v1 r0 vLast r2
    by_cases ey : y=c
    · subst y
      exact F.path b a c d e (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) v0 r1 vLast r2
    by_cases ey : y=d
    · subst y
      exact F.loop _ last
    by_cases ey : y=e
    · subst y
      exact n2 rfl
    exact F.twoStars a b c d e y (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 r1 r2 last
  by_cases ex : x=e
  · subst x
    by_cases ey : y=a
    · subst y
      exact F.fork a b c e d (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 r1 vLast v2
    by_cases ey : y=b
    · subst y
      exact F.path c a b e d (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) v1 r0 vLast v2
    by_cases ey : y=c
    · subst y
      exact F.path b a c e d (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) v0 r1 vLast v2
    by_cases ey : y=d
    · subst y
      exact n2 (Sym2.eq_swap ..)
    by_cases ey : y=e
    · subst y
      exact F.loop _ last
    exact F.twoStars a b c e d y (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 r1 v2 last
  by_cases ey : y=a
  · subst y
    exact F.threeStar a b c d x e (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 r1 vLast r2
  by_cases ey : y=b
  · subst y
    exact F.matching a c b x d e (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r1 vLast r2
  by_cases ey : y=c
  · subst y
    exact F.matching a b c x d e (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 vLast r2
  by_cases ey : y=d
  · subst y
    exact F.twoStars a b c d e x (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 r1 r2 vLast
  by_cases ey : y=e
  · subst y
    exact F.twoStars a b c e d x (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 r1 v2 vLast
  exact F.matching a b d e x y (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 r2 last

theorem exclude {U : Finset (Sym2 α)} (F : Forbidden U) (card : U.card=4) (a b c d : α)
    (nd : [a,b,c,d].Nodup) (r0 : s(a,b)∈U) (r1 : s(c,d)∈U) : False := by
  classical
  obtain ⟨x,y,last,n0,n1,n2⟩ := more card s(a,b) s(c,d) s(c,d)
  have xy : x≠y := by rintro rfl; exact F.loop _ last
  simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or] at nd
  have v0 := rev r0
  have v1 := rev r1
  have vLast := rev last
  by_cases ex : x=a
  · subst x
    by_cases ey : y=a
    · subst y
      exact F.loop _ last
    by_cases ey : y=b
    · subst y
      exact n0 rfl
    by_cases ey : y=c
    · subst y
      exact extendPath F card b a c d (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) v0 last r1
    by_cases ey : y=d
    · subst y
      exact extendPath F card b a d c (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) v0 last v1
    exact extendStar F card a b y c d (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 last r1
  by_cases ex : x=b
  · subst x
    by_cases ey : y=a
    · subst y
      exact n0 (Sym2.eq_swap ..)
    by_cases ey : y=b
    · subst y
      exact F.loop _ last
    by_cases ey : y=c
    · subst y
      exact extendPath F card a b c d (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 last r1
    by_cases ey : y=d
    · subst y
      exact extendPath F card a b d c (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 last v1
    exact extendStar F card b a y c d (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) v0 last r1
  by_cases ex : x=c
  · subst x
    by_cases ey : y=a
    · subst y
      exact extendPath F card b a c d (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) v0 vLast r1
    by_cases ey : y=b
    · subst y
      exact extendPath F card a b c d (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 vLast r1
    by_cases ey : y=c
    · subst y
      exact F.loop _ last
    by_cases ey : y=d
    · subst y
      exact n1 rfl
    exact extendStar F card c d y a b (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r1 last r0
  by_cases ex : x=d
  · subst x
    by_cases ey : y=a
    · subst y
      exact extendPath F card b a d c (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) v0 vLast v1
    by_cases ey : y=b
    · subst y
      exact extendPath F card a b d c (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 vLast v1
    by_cases ey : y=c
    · subst y
      exact n1 (Sym2.eq_swap ..)
    by_cases ey : y=d
    · subst y
      exact F.loop _ last
    exact extendStar F card d c y a b (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) v1 last r0
  by_cases ey : y=a
  · subst y
    exact extendStar F card a b x c d (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 vLast r1
  by_cases ey : y=b
  · subst y
    exact extendStar F card b a x c d (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) v0 vLast r1
  by_cases ey : y=c
  · subst y
    exact extendStar F card c d x a b (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r1 vLast r0
  by_cases ey : y=d
  · subst y
    exact extendStar F card d c x a b (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) v1 vLast r0
  exact F.matching a b c d x y (by simp only [List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]; grind only) r0 r1 last

#print axioms exclude
end EdgeCensus
