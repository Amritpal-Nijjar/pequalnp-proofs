import HiddenRaw4
import ResidualShrink
import StarGrowth

namespace StarLeafBudget
open PEqualNP.CircuitLowerBounds PEqualNP.TopForm PEqualNP.EdgeOwnership
open PEqualNP.MetaComplexity.NestedCover PEqualNP.CleanedNonEdge
open PEqualNP.Outside.L_meta_7465_aux PEqualNP.Outside.L_meta_7465_aux.Routing
variable {n : ℕ} {G : SimpleGraph (Fin n)} [DecidableRel G.Adj] {C : Circuit}
attribute [local instance] gateOpDecEq

noncomputable abbrev hidden (G : SimpleGraph (Fin n)) [DecidableRel G.Adj] (C : Circuit) :=
  (orN G C \ lam G C) \ ActiveOr.atTops G C

/-- Two leaves of the same residual star cannot both lie in a raw support
that is small or has a common neighbour along retained edges. -/
theorem thin {v : Fin n} {L A : Finset (Fin n)} (four : NoFourCycle G)
    (res : ∀ l∈L, s(v,l)∈Ustar G C) (good : SixGeometry.RawOK G C A) :
    (A ∩ L).card ≤ 1 := by
  classical
  apply Finset.card_le_one.mpr
  intro p hp q hq
  by_contra ne
  obtain ⟨cp, lp⟩ := Finset.mem_inter.mp hp
  obtain ⟨cq, lq⟩ := Finset.mem_inter.mp hq
  exact SixGeometry.forbid_cross four good ne cp cq (Sym2.eq_swap .. ▸ res p lp)
    (SimpleGraph.mem_edgeFinset.mp (Finset.mem_sdiff.mp (res q lq)).1)

private theorem trim_subset (four : NoFourCycle G) (ao : IsAO2 n C)
    (H : Finset ℕ) (exceptional : H ⊆ orN G C \ lam G C)
    (controlled : ∀ w < n+C.gates.length, (∀ j∈H, w ≠ n+j) → SixGeometry.RawOK G C (orIn n C w))
    (v : Fin n) (L : Finset (Fin n))
    (res : ∀ l∈L, s(v,l)∈Ustar G C) :
    ∀ t ≤ C.gates.length, ∃ K ⊆ L,
      L.card ≤ K.card + (H.filter (fun j => j<t)).card ∧
      ∀ w < n+t, ((orIn n C w) ∩ K).card ≤ 1 := by
  classical
  have regular (w : ℕ) (bw : w < n+C.gates.length)
      (clean : ∀ j∈H, w ≠ n+j) (K : Finset (Fin n)) (sub : K ⊆ L) :
      ((orIn n C w) ∩ K).card ≤ 1 :=
    thin four (fun x hx => res x (sub hx)) (controlled w bw clean)
  intro t
  induction t with
  | zero =>
    intro _
    refine ⟨L, Finset.Subset.rfl, by simp, ?_⟩
    intro w hw
    exact regular w (by omega) (fun j _ => by omega) L Finset.Subset.rfl
  | succ t ih =>
    intro size
    have lt : t < C.gates.length := by omega
    obtain ⟨K,sub,budget,old⟩ := ih (by omega)
    by_cases hid : t∈H
    · have inOr := (Finset.mem_sdiff.mp (exceptional hid)).1
      have op : (gateAt C t).op = GateOp.or := (Finset.mem_filter.mp inOr).2.1
      let cut := (side (n := n) C t 0) ∩ K
      let T := K \ cut
      have subT : T ⊆ K := Finset.sdiff_subset
      have cutSub : cut ⊆ K := Finset.inter_subset_right
      have cutSmall : cut.card ≤ 1 := old (opnd C t 0) (opndBound ao lt _)
      have split : T.card + cut.card = K.card := Finset.card_sdiff_add_card_eq_card cutSub
      have below : H.filter (fun j => j < t+1) = insert t (H.filter (fun j => j<t)) := by
        ext i
        simp only [Finset.mem_filter,Finset.mem_insert]
        constructor
        · rintro ⟨hi,bi⟩
          by_cases eq : i=t
          · exact Or.inl eq
          · exact Or.inr ⟨hi,by omega⟩
        · rintro (rfl|⟨hi,bi⟩)
          · exact ⟨hid,by omega⟩
          · exact ⟨hi,by omega⟩
      have add : (H.filter (fun j => j<t+1)).card = (H.filter (fun j => j<t)).card+1 := by
        rw [below,Finset.card_insert_of_notMem (by simp)]
      refine ⟨T,subT.trans sub, ?_, ?_⟩
      · change L.card ≤ T.card + (H.filter (fun j => j<t+1)).card
        change L.card ≤ K.card + (H.filter (fun j => j<t)).card at budget
        omega
      intro w hw
      by_cases earlier : w<n+t
      · exact (Finset.card_le_card (Finset.inter_subset_inter_left (s := orIn n C w) subT)).trans (old w earlier)
      have eq : w=n+t := by omega
      rw [eq,orRawUnion ao lt op]
      have transfer : ((side (n:=n) C t 0 ∪ side C t 1) ∩ T) ⊆ side C t 1 ∩ K := by
        intro u hu
        obtain ⟨mem,inT⟩ := Finset.mem_inter.mp hu
        have inK := subT inT
        refine Finset.mem_inter.mpr ⟨?_, inK⟩
        rcases Finset.mem_union.mp mem with h | h
        · exact ((Finset.mem_sdiff.mp inT).2 (Finset.mem_inter.mpr ⟨h,inK⟩)).elim
        · exact h
      exact (Finset.card_le_card transfer).trans (old (opnd C t 1) (opndBound ao lt _))
    · refine ⟨K,sub,?_,?_⟩
      · have inc : H.filter (fun j => j<t) ⊆ H.filter (fun j => j<t+1) := by
          intro j hj
          obtain ⟨inH, prior⟩ := Finset.mem_filter.mp hj
          exact Finset.mem_filter.mpr ⟨inH, Nat.lt_succ_of_lt prior⟩
        exact budget.trans (Nat.add_le_add_left (Finset.card_le_card inc) _)
      intro w hw
      by_cases earlier : w<n+t
      · exact old w earlier
      have eq : w = n+t := by omega
      apply regular w (by omega) _ K sub
      intro j hj same
      have je : j=t := by omega
      exact hid (je ▸ hj)

/-- Each hidden exceptional OR can increase the number of leaves to be
accounted for by at most one. Each remaining leaf needs a dirty AND. -/
theorem leaf_bound_of_control (four : NoFourCycle G) (least : IsLeastAO G C) (top : TopForm G C)
    (H : Finset ℕ) (exceptional : H ⊆ orN G C \ lam G C)
    (controlled : ∀ w < n+C.gates.length, (∀ j∈H, w ≠ n+j) → SixGeometry.RawOK G C (orIn n C w))
    (v : Fin n)
    (center : ∀ e∈Ustar G C, v∈e) (L : Finset (Fin n))
    (res : ∀ l∈L, s(v,l)∈Ustar G C) :
    L.card ≤ (junk G C).card + H.card := by
  classical
  obtain ⟨K,sub,budget,thinK⟩ := trim_subset four least.1 H exceptional controlled v L res C.gates.length (le_refl _)
  have sparse (j : ℕ) (hj : j∈junk G C) (b : Fin 2) :
      ((side (n:=n) C j b) ∩ K).card ≤ 1 := by
    obtain ⟨len,_,_⟩ := junkData hj
    have h := opndBound least.1 len b
    exact thinK _ (by omega)
  have changes (l : Fin n) (hl : l∈K) :
      ∃ j∈junk G C, gateVal n C j (pairInput v v)=false ∧ gateVal n C j (pairInput v l)=true := by
    have edge := res l (sub hl)
    obtain ⟨_,_,_,j,hj,_,on⟩ := PEqualNP.Outside.L_meta_8005.residualTrace least top edge
    refine ⟨j,hj, Bool.eq_false_iff.mpr ?_, on⟩
    intro hot
    have graphEdges : G.edgeFinset.Nonempty := ⟨_, (Finset.mem_sdiff.mp edge).1⟩
    obtain ⟨p,q,hpq,pv,qv,_⟩ := ResidualChange.residual_witness least top graphEdges hj v hot
    rcases Sym2.mem_iff.mp (center _ hpq) with e|e
    · exact pv e.symm
    · exact qv e.symm
  have residual := StarGrowth.first_changes least.1 top v K sparse changes
  have count := Finset.card_le_card (Finset.filter_subset (fun j => j < C.gates.length) H)
  omega

theorem leaf_bound (four : NoFourCycle G) (least : IsLeastAO G C) (top : TopForm G C)
    (empty : centreless G C = ∅) (v : Fin n)
    (center : ∀ e∈Ustar G C, v∈e) (L : Finset (Fin n))
    (res : ∀ l∈L, s(v,l)∈Ustar G C) :
    L.card ≤ (junk G C).card + (hidden G C).card :=
  leaf_bound_of_control four least top _ Finset.sdiff_subset
    (HiddenRaw4.raw_except least.1 empty) v center L res

#print axioms leaf_bound
end StarLeafBudget
