import HiddenRaw4

namespace OrdinaryStar
open PEqualNP.CircuitLowerBounds PEqualNP.TopForm PEqualNP.EdgeOwnership
open PEqualNP.MetaComplexity.NestedCover PEqualNP.CleanedNonEdge
open PEqualNP.Outside.L_meta_7465_aux PEqualNP.Outside.L_meta_7465_aux.Routing
variable {n : ℕ} {G : SimpleGraph (Fin n)} [DecidableRel G.Adj] {C : Circuit}
attribute [local instance] gateOpDecEq

/-- An ordinary OR reaches a top whose opposite side contains one vertex.
Consequently the raw-support argument of HiddenRaw4 still applies to these
wires even when other tops have an empty side. -/
theorem raw_control (ao : IsAO2 n C) (w : ℕ) (bound : w < n+C.gates.length)
    (outside : ∀ k∈orN G C \ lam G C, w≠n+k) : SixGeometry.RawOK G C (orIn n C w) := by
  classical
  by_cases small : (orIn n C w).card ≤ 1
  · exact Or.inl small
  have nz : (orIn n C w).Nonempty := Finset.card_pos.mp (by omega)
  by_cases input : w<n
  · exfalso
    apply small
    apply Finset.card_le_one.mpr
    have eq (u : Fin n) (m : u∈orIn n C w) : u.val = w := by
      rcases Relation.ReflTransGen.cases_head (mem_orIn_reach u m) with h | ⟨_,step,_⟩
      · exact h.symm
      · obtain ⟨j,_,h,_,_,_⟩ := step
        omega
    intro u hu v hv
    exact Fin.ext ((eq u hu).trans (eq v hv).symm)
  obtain ⟨h,rfl⟩ : ∃ h, w = n+h := ⟨w-n,by omega⟩
  obtain ⟨u,mu⟩ := nz
  have len : h < C.gates.length := by omega
  have op : (gateAt C h).op = GateOp.or := by
    rcases ao.1 _ (gateAt_mem len) with ha|ho
    · rw [andRawEmpty ha] at mu
      exact (Finset.notMem_empty _ mu).elim
    · exact ho
  have nonbelow : ¬BelowF G C h := by
    intro below
    have yes := reach_var_val (pairInput u u) _ u (mem_orIn_reach u mu) (pairInput_left u u)
    exact G.irrefl ((graphFun_pair G u u).mp (below _ yes))
  have member : h∈orN G C := Finset.mem_filter.mpr ⟨Finset.mem_range.mpr len,op,nonbelow⟩
  have regular : h∈lam G C := by
    by_contra missing
    exact outside h (Finset.mem_sdiff.mpr ⟨member,missing⟩) rfl
  obtain ⟨_,_,_,a,ha,b,one,route⟩ := Finset.mem_filter.mp regular
  obtain ⟨z,mz⟩ := Finset.card_pos.mp (show 0 < (side (n:=n) C a (1-b)).card by omega)
  right
  refine ⟨z,fun x hx => ?_⟩
  have atPort := reach_mem_orIn x ((orReaches_reach h _ route).1.trans (mem_orIn_reach x hx))
  exact (cleanAdj ao ha b atPort mz).symm

#print axioms raw_control
end OrdinaryStar
