import BothTable
import SixGeometry
namespace BothGeometry
open PEqualNP.CircuitLowerBounds PEqualNP.TopForm PEqualNP.EdgeOwnership
open PEqualNP.MetaComplexity.NestedCover PEqualNP.CleanedNonEdge
open PEqualNP.Outside.L_meta_7465_aux PEqualNP.Outside.L_meta_7465_aux.Routing
open Chart6 BothTable
variable {n : ℕ} {G : SimpleGraph (Fin n)} [DecidableRel G.Adj] {C : Circuit}
def edgeSet (tri : Bool) (v : V→Fin n) := Finset.univ.image fun e : Fin 4 => s(v (L (edges tri e)),v (R (edges tri e)))
theorem each {tri : Bool} {v : V→Fin n} (shape : Ustar G C=edgeSet tri v) (e : Fin 4) :
    s(v (L (edges tri e)),v (R (edges tri e)))∈Ustar G C := by
  rw [shape]; exact Finset.mem_image.mpr ⟨e,Finset.mem_univ _,rfl⟩
abbrev residual (tri : Bool) (G : SimpleGraph (Fin n)) [DecidableRel G.Adj] (C : Circuit) (v : V→Fin n) :=
  ∀ e : Fin 4, s(v (L (edges tri e)),v (R (edges tri e)))∈Ustar G C

theorem chart (bip : G.IsBipartite) (tri : Bool) (v : V→Fin n) (res : residual tri G C v) :
    ∃ flip, ∃ col : G.Coloring (Fin 2), ∀ p q, col (v p)=col (v q) ↔ color tri flip p=color tri flip q := by
  obtain ⟨col⟩ := bip
  have e (i : Fin 4) := SimpleGraph.mem_edgeFinset.mp (Finset.mem_sdiff.mp (res i)).1
  have t1 : col (v 0)≠col (v 1) := col.valid (e 0)
  have t2 : col (v 0)≠col (v 2) := col.valid (e 1)
  have t4 : col (v (if tri then 0 else 3))≠col (v 4) := col.valid (e 2)
  have t5 : col (v 3)≠col (v 5) := col.valid (e 3)
  let flip := decide (col (v 3)≠col (v 0))
  have value (p : V) : col (v p) = if color tri flip p then col (v 1) else col (v 0) := by
    cases tri <;> by_cases eq : col (v 3)=col (v 0) <;> fin_cases p <;> simp [flip,color,eq] at t4 ⊢ <;> omega
  refine ⟨flip,col,fun p q => ?_⟩
  rw [value p,value q]; cases a : color tri flip p <;> cases b : color tri flip q <;> simp [t1,Ne.symm t1]

abbrev bit (v : V→Fin n) (A : Finset (Fin n)) (i : V) := decide (v i∈A)
theorem raw_mono {tri flip : Bool} (v : V→Fin n) (col : G.Coloring (Fin 2))
    (align : ∀ p q, col (v p)=col (v q) ↔ color tri flip p=color tri flip q)
    (A : Finset (Fin n)) (good : SixGeometry.RawOK G C A) : mono tri flip (bit v A)=true := by
  have same {p q : V} (one : v p∈A) (two : v q∈A) : color tri flip p=color tri flip q := by
    apply (align p q).1
    rcases good with small|⟨z,old⟩
    · exact congrArg col (Finset.card_le_one.mp small _ one _ two)
    · have t := col.valid (SimpleGraph.deleteEdges_adj.mp (old _ one)).1
      have u := col.valid (SimpleGraph.deleteEdges_adj.mp (old _ two)).1; omega
  apply Bool.or_eq_true_iff.mpr
  by_cases hit : ∃ i, v i∈A ∧ color tri flip i=true
  · obtain ⟨i,m,yes⟩ := hit
    right; apply (all6_iff _).2; intro p
    by_cases belongs : v p∈A
    · simp [bit,belongs,(same belongs m).trans yes]
    · simp [bit,belongs]
  · left; apply (all6_iff _).2; intro p
    by_cases belongs : v p∈A
    · have off : color tri flip p=false := Bool.eq_false_iff.mpr (fun yes => hit ⟨p,belongs,yes⟩)
      simp [bit,belongs,off]
    · simp [bit,belongs]

theorem raw_siblings (four : NoFourCycle G) (tri : Bool) (v : V→Fin n) (inj : Function.Injective v)
    (res : residual tri G C v) (A : Finset (Fin n)) (ok : SixGeometry.RawOK G C A) :
    siblings tri (bit v A)=true := by
  have ban {p q z : V} (ne : p≠q) (pz : s(v z,v p)∈Ustar G C) (qz : s(v z,v q)∈Ustar G C) :
      !(bit v A p && bit v A q)=true := by
    have no : ¬(v p∈A ∧ v q∈A) := fun both => SixGeometry.forbid_cross four ok (inj.ne ne) both.1 both.2
      (Sym2.eq_swap ▸ pz) (SimpleGraph.mem_edgeFinset.mp (Finset.mem_sdiff.mp qz).1)
    simpa [bit,Bool.and_eq_false_iff] using not_and_or.mp no
  cases tri
  · exact Bool.and_eq_true_iff.mpr ⟨ban (p:=1) (q:=2) (z:=0) (by decide) (res 0) (res 1),
      ban (p:=4) (q:=5) (z:=3) (by decide) (res 2) (res 3)⟩
  · exact Bool.and_eq_true_iff.mpr ⟨ban (p:=1) (q:=2) (z:=0) (by decide) (res 0) (res 1),
      Bool.and_eq_true_iff.mpr ⟨ban (p:=1) (q:=4) (z:=0) (by decide) (res 0) (res 2),
      ban (p:=2) (q:=4) (z:=0) (by decide) (res 1) (res 2)⟩⟩

theorem upper (four : NoFourCycle G) {tri flip : Bool} (v : V→Fin n) (inj : Function.Injective v)
    (res : residual tri G C v) (col : G.Coloring (Fin 2))
    (align : ∀ p q, col (v p)=col (v q) ↔ color tri flip p=color tri flip q)
    (Raws : Fin 4→Finset (Fin n)) (ok : ∀ i,SixGeometry.RawOK G C (Raws i)) (p q : V) (edge : G.Adj (v p) (v q)) :
    allowed tri flip (fun i => bit v (Raws i)) p q=true := by
  let m := fun i => bit v (Raws i)
  have one (p q x z : V) (xz : s(v x,v z)∈Ustar G C) (pq : G.Adj (v p) (v q)) : direction m p q x z=true := by
    by_cases e : p=x
    · subst p; by_cases f : q=z
      · simp [direction,f]
      · have sp : sep m q z=true := by
          apply (SixTerms.all4_iff _).2; intro i
          have no : ¬(v q∈Raws i ∧ v z∈Raws i) := fun both => SixGeometry.forbid_cross four (ok i)
            (inj.ne (Ne.symm f)) both.2 both.1 (Sym2.eq_swap ▸ xz) pq
          simpa [m,bit,Bool.and_eq_false_iff] using not_and_or.mp no
        simp [direction,sp]
    · simp [direction,e]
  apply Bool.and_eq_true_iff.mpr
  refine ⟨by simpa using (fun eq => col.valid edge ((align p q).2 eq)),(SixTerms.all4_iff _).2 (fun i => ?_)⟩
  let x := L (edges tri i); let z := R (edges tri i)
  have xz := res i; have zx : s(v z,v x)∈Ustar G C := Sym2.eq_swap ▸ xz
  simp only [Bool.and_eq_true]
  exact ⟨⟨⟨one p q x z xz edge,one p q z x zx edge⟩,one q p x z xz edge.symm⟩,one q p z x zx edge.symm⟩
end BothGeometry
