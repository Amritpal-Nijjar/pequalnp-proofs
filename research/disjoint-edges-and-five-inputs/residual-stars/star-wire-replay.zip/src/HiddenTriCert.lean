import HiddenStarCert
namespace HiddenTriCert
open HiddenStarCert (V M)
def good (x : V→Bool) := !((x 0 || x 3) && (x 1 || x 2 || x 4 || x 5)) &&
  !(x 1 && x 2) && !(x 1 && x 4) && !(x 2 && x 4)
def capped (x : V→Bool) := !(x 1 && x 2 && x 4)
def compatible (x y : V→Bool) := good x || good y || HiddenStarCert.equal x y
def raw (m : M) := compatible (m 0) (m 1) && compatible (m 0) (m 2) && compatible (m 0) (m 3) &&
  compatible (m 1) (m 2) && compatible (m 1) (m 3) && compatible (m 2) (m 3) &&
  capped (m 0) && capped (m 1) && capped (m 2) && capped (m 3)
def tests (y : V→V→Bool) := y 0 1 && y 0 2 && y 0 4 && y 3 5 &&
  !y 0 0 && !y 3 3 && !y 0 3 && !y 0 5 && !y 3 1 && !y 3 2 && !y 3 4
set_option maxHeartbeats 6000000
set_option maxRecDepth 60000
theorem impossible (m : M) (a b r s : Bool) : (raw m && tests (HiddenStarCert.signal m a b r s))=false := by
  simp only [raw,compatible,capped,good,HiddenStarCert.equal,tests,HiddenStarCert.signal,HiddenStarCert.lit]
  kernel_bool_sat
#print axioms impossible
end HiddenTriCert
