import Chart6
namespace BothTable
open Chart6
def color (tri flip : Bool) : V→Bool := ![false,true,true,flip,if tri then true else !flip,!flip]
def mono (tri flip : Bool) (s : V→Bool) := (all6 fun i => !(s i && color tri flip i)) ||
  (all6 fun i => !(s i && !color tri flip i))
def siblings (tri : Bool) (s : V→Bool) := !(s 1 && s 2) &&
  (if tri then !(s 1 && s 4) && !(s 2 && s 4) else !(s 4 && s 5))
def sep (m : M) (p q : V) := SixTerms.all4 fun i => !(m i p && m i q)
def direction (m : M) (p q x z : V) := !(p == x) || (q == z) || sep m q z
def allowed (tri flip : Bool) (m : M) (p q : V) :=
  (color tri flip p != color tri flip q) && SixTerms.all4 fun i =>
    let e := edges tri i
    direction m p q (L e) (R e) && direction m p q (R e) (L e) &&
    direction m q p (L e) (R e) && direction m q p (R e) (L e)
def any4 (f : Fin 4→Bool) := f 0 || f 1 || f 2 || f 3
theorem any4_of (f : Fin 4→Bool) (i : Fin 4) (yes : f i=true) : any4 f=true := by
  fin_cases i <;> simp_all [any4]
def needed (tri : Bool) (d : V→V→Bool) := all6 fun i => !d i i || any4 fun k =>
  let e := edges tri k
  !vert i (L e) (R e) && d (L e) (R e)
def guard (tri : Bool) (m : M) (a b : Bool) :=
  !tri || !(d1 m a b 0 0 && !d0 m 0 1 && !d0 m 0 2 && !d0 m 0 4)
def wins (tri flip : Bool) (m : M) (a b : Bool) (e : E) (k : Fin 5) :=
  term m a b e k (L e) (R e) && all6 fun p => all6 fun q =>
    !term m a b e k p q || allowed tri flip m p q
def passes (tri flip : Bool) (m : M) (a b : Bool) :=
  SixTerms.all4 (fun i => mono tri flip (m i) && siblings tri (m i)) &&
  needed tri (d0 m) && needed tri (d1 m a b) && guard tri m a b &&
  SixTerms.all4 fun i => SixTerms.some5 fun k => wins tri flip m a b (edges tri i) k
theorem needed_of (tri : Bool) (d : V→V→Bool) (w : ∀ i, d i i=true → ∃ e : Fin 4,
    (i≠L (edges tri e) ∧ i≠R (edges tri e)) ∧ d (L (edges tri e)) (R (edges tri e))=true) :
    needed tri d=true := by
  apply (all6_iff _).2; intro i; cases h : d i i
  · simp
  · obtain ⟨e,⟨l,r⟩,on⟩ := w i h
    simp only [Bool.not_true,Bool.false_or]
    apply any4_of _ e
    simp [vert,l,r,on]
theorem accept (tri flip : Bool) (m : M) (a b : Bool)
    (shape : ∀ i, (mono tri flip (m i) && siblings tri (m i))=true)
    (j : needed tri (d0 m)=true) (h : needed tri (d1 m a b)=true) (g : guard tri m a b=true)
    (top : ∀ i, ∃ k, term m a b (edges tri i) k (L (edges tri i)) (R (edges tri i))=true ∧
      ∀ p q, term m a b (edges tri i) k p q=true → allowed tri flip m p q=true) :
    passes tri flip m a b=true := by
  simp only [passes,Bool.and_eq_true]
  refine ⟨⟨⟨⟨(SixTerms.all4_iff _).2 shape,j⟩,h⟩,g⟩,(SixTerms.all4_iff _).2 (fun i => ?_)⟩
  obtain ⟨k,yes,safe⟩ := top i
  apply SixTerms.some5_of (k:=k); apply Bool.and_eq_true_iff.mpr
  refine ⟨yes,(all6_iff _).2 (fun p => (all6_iff _).2 (fun q => ?_))⟩
  cases h : term m a b (edges tri i) k p q <;> simp [h,safe p q]
end BothTable
