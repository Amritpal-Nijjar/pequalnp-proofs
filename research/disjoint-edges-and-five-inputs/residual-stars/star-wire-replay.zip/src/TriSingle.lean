import OneSignal
import TriRaw
namespace TriSingle
open PEqualNP.CircuitLowerBounds PEqualNP.TopForm PEqualNP.EdgeOwnership
open PEqualNP.MetaComplexity.NestedCover PEqualNP.CleanedNonEdge
open PEqualNP.Outside.L_meta_7465_aux PEqualNP.Outside.L_meta_7465_aux.Routing
open Chart6
variable {n : ℕ} {G : SimpleGraph (Fin n)} [DecidableRel G.Adj] {C : Circuit}

theorem common {h : ℕ} (one : ActiveOr.atTops G C={h}) {w : Fin n} (mem : w∈orIn n C (n+h)) :
    ∀ g∈ActiveOr.atTops G C, w∈orIn n C (n+g) := by
  intro g mg
  have eq : g=h := Finset.mem_singleton.mp (one ▸ mg)
  simpa [eq] using mem

/-- Every raw vertex reaches the same endpoint of the isolated edge. Its
    color is fixed by the common anchor at the three-leaf star. -/
theorem singleton (four : NoFourCycle G) (bip : G.IsBipartite) (least : IsLeastAO G C)
    (empty : centreless G C=∅) {h : ℕ} (one : ActiveOr.atTops G C={h}) (v : V→Fin n) (inj : Function.Injective v)
    (e1 : s(v 0,v 1)∈Ustar G C) (e2 : s(v 0,v 2)∈Ustar G C) (e5 : s(v 3,v 5)∈Ustar G C)
    {w : Fin n} (mem : w∈orIn n C (n+h)) (wd : (G.deleteEdges ↑(Ustar G C)).Adj w (v 3)) :
    orIn n C (n+h)={w} ∧ (G.deleteEdges ↑(Ustar G C)).Adj w (v 0) := by
  classical
  obtain ⟨col⟩ := bip
  have rawA (z : Fin n) (mz : z∈orIn n C (n+h)) :=
    VisibleRaw.branch_vertex four least empty z (common one mz) (inj.ne (by decide)) e1 e2
  have wa := rawA w mem
  have aw := col.valid (SimpleGraph.deleteEdges_adj.mp wa).1
  have dw := col.valid (SimpleGraph.deleteEdges_adj.mp wd).1
  have df : col (v 3)≠col (v 5) := col.valid (SimpleGraph.mem_edgeFinset.mp (Finset.mem_sdiff.mp e5).1)
  have cn (z : Fin n) (mz : z∈orIn n C (n+h)) : z∈Finset.univ.filter (fun x => G.Adj (v 0) x ∧ G.Adj (v 3) x) := by
    have za := (SimpleGraph.deleteEdges_adj.mp (rawA z mz)).1
    have az := col.valid za
    rcases VisibleRaw.old_neighbor least empty z (common one mz) _ _ e5 with zd|zf
    · exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,za.symm,(SimpleGraph.deleteEdges_adj.mp zd).1.symm⟩
    · have fz := col.valid (SimpleGraph.deleteEdges_adj.mp zf).1
      omega
  refine ⟨?_,wa⟩; ext z; rw [Finset.mem_singleton]
  exact ⟨fun mz => Finset.card_le_one.mp (four (v 0) (v 3) (inj.ne (by decide))) z (cn z mz) w (cn w mem),fun eq => eq ▸ mem⟩

theorem oriented (four : NoFourCycle G) (bip : G.IsBipartite) (least : IsLeastAO G C)
    (top : TopForm G C) (empty : centreless G C=∅) (two : (junk G C).card=2)
    (twoOr : (orN G C \ lam G C).card=2) {h : ℕ} (one : ActiveOr.atTops G C={h})
    (v : V→Fin n) (inj : Function.Injective v) (e1 : s(v 0,v 1)∈Ustar G C)
    (e2 : s(v 0,v 2)∈Ustar G C) (e4 : s(v 0,v 4)∈Ustar G C) (e5 : s(v 3,v 5)∈Ustar G C)
    {w : Fin n} (mem : w∈orIn n C (n+h)) (wd : (G.deleteEdges ↑(Ustar G C)).Adj w (v 3)) : False := by
  classical
  obtain ⟨only,wa⟩ := singleton four bip least empty one v inj e1 e2 e5 mem wd
  have a := SimpleGraph.deleteEdges_adj.mp wa.symm
  have d := SimpleGraph.deleteEdges_adj.mp wd.symm
  have acrossA {x : Fin n} (edge : s(v 0,x)∈Ustar G C) : x≠w ∧ ¬G.Adj (v 3) x := by
    have ne : x≠w := by rintro rfl; exact a.2 edge
    exact ⟨ne,FourPath.no_chord four (inj.ne (by decide)) (Ne.symm ne) d.1 a.1.symm
      (SimpleGraph.mem_edgeFinset.mp (Finset.mem_sdiff.mp edge).1)⟩
  have fne : v 5≠w := by intro eq; exact d.2 (eq ▸ e5)
  have acrossD := FourPath.no_chord four (inj.ne (by decide)) (Ne.symm fne) a.1 d.1.symm
    (SimpleGraph.mem_edgeFinset.mp (Finset.mem_sdiff.mp e5).1)
  have avoid (i : V) : v i≠w := by
    fin_cases i
    · exact a.1.ne
    · exact (acrossA e1).1
    · exact (acrossA e2).1
    · exact d.1.ne
    · exact (acrossA e4).1
    · exact fne
  have center : ¬G.Adj (v 0) (v 3) := by
    intro e; obtain ⟨col⟩ := bip
    have diff := col.valid e; have aw := col.valid a.1; have dw := col.valid d.1; omega
  have seen : h∈ActiveOr.atTops G C := one ▸ Finset.mem_singleton_self _
  obtain ⟨j,k,lt,eqJ⟩ := ChartPhysical.sorted_pair two
  let m := OneSignal.masks v C j k
  have raw : HiddenTriCert.raw m=true := by
    rw [show m = fun i p => decide (v p∈orIn n C (OneSignal.port C j k i)) from OneSignal.masks_eq v C j k]
    exact TriRaw.physical_masks least.1 empty twoOr one v _ (OneSignal.port_bound least.1 eqJ)
      (TriRaw.good_on_three four bip v inj w a.1.symm d.1.symm e1 e2 e4 e5)
  obtain ⟨alpha,beta,r,s,signal⟩ := OneSignal.projected least.1 top seen lt eqJ v only avoid
  have atA {t : Fin n} (e : s(v 0,t)∈Ustar G C) := VisibleSignal4.center_test bip least empty one mem a.1.symm e
  have atD := VisibleSignal4.center_test bip least empty one mem d.1.symm e5
  have offA (q : V) (no : ¬G.Adj (v 0) (v q)) := (atA e1).2 _ (pairInput_left _ _) (OneSignal.graph_off no)
  have offD (q : V) (no : ¬G.Adj (v 3) (v q)) := atD.2 _ (pairInput_left _ _) (OneSignal.graph_off no)
  have tests : HiddenTriCert.tests (HiddenStarCert.signal m alpha beta r s)=true := by
    simp only [HiddenTriCert.tests,Bool.and_eq_true,Bool.not_eq_true',show m = OneSignal.masks v C j k from rfl,signal]
    exact ⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨(atA e1).1,(atA e2).1⟩,(atA e4).1⟩,atD.1⟩,offA 0 G.irrefl⟩,
      offD 3 G.irrefl⟩,offA 3 center⟩,offA 5 acrossD⟩,offD 1 (acrossA e1).2⟩,offD 2 (acrossA e2).2⟩,offD 4 (acrossA e4).2⟩
  exact Bool.false_ne_true ((HiddenTriCert.impossible m alpha beta r s).symm.trans (Bool.and_eq_true_iff.mpr ⟨raw,tests⟩))

def swapEnds : V→V := ![0,1,2,5,4,3]
theorem swap_inj : Function.Injective swapEnds := by decide
/-- The isolated edge has no preferred orientation. Besides these four
    residual edges the graph may have any number of additional residuals. -/
theorem no_star3_edge_single (four : NoFourCycle G) (bip : G.IsBipartite) (least : IsLeastAO G C)
    (top : TopForm G C) (empty : centreless G C=∅) (two : (junk G C).card=2)
    (twoOr : (orN G C \ lam G C).card=2) {h : ℕ} (one : ActiveOr.atTops G C={h})
    (v : V→Fin n) (inj : Function.Injective v) (e1 : s(v 0,v 1)∈Ustar G C)
    (e2 : s(v 0,v 2)∈Ustar G C) (e4 : s(v 0,v 4)∈Ustar G C) (e5 : s(v 3,v 5)∈Ustar G C) : False := by
  classical
  have seen : h∈ActiveOr.atTops G C := one ▸ Finset.mem_singleton_self _
  obtain ⟨w,mw⟩ := (Finset.mem_filter.mp seen).2.1
  rcases VisibleRaw.old_neighbor least empty w (common one mw) _ _ e5 with first|second
  · exact oriented four bip least top empty two twoOr one v inj e1 e2 e4 e5 mw first
  · exact oriented four bip least top empty two twoOr one (v ∘ swapEnds) (inj.comp swap_inj)
      e1 e2 e4 (Sym2.eq_swap ▸ e5) mw second
#print axioms no_star3_edge_single
end TriSingle
