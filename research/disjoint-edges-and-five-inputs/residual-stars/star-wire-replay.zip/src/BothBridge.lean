import BothGeometry
import ChartTops
import LeafCount
namespace BothBridge
open PEqualNP.CircuitLowerBounds PEqualNP.TopForm PEqualNP.EdgeOwnership
open PEqualNP.MetaComplexity.NestedCover PEqualNP.CleanedNonEdge
open PEqualNP.Outside.L_meta_7465_aux PEqualNP.Outside.L_meta_7465_aux.Routing
open Chart6 BothTable BothGeometry
variable {n : ℕ} {G : SimpleGraph (Fin n)} [DecidableRel G.Adj] {C : Circuit}

theorem essential (least : IsLeastAO G C) (top : TopForm G C) {j : ℕ} (dirty : j∈junk G C)
    (tri : Bool) (v : V→Fin n) (shape : Ustar G C=edgeSet tri v) (d : V→V→Bool)
    (eq : ∀ p q, d p q=ChartPhysical.Vg v C j p q) : needed tri d=true := by
  have pos : G.edgeFinset.Nonempty := ⟨_,(Finset.mem_sdiff.mp (each shape 0)).1⟩
  apply needed_of; intro i yes
  obtain ⟨p,q,m,pu,qu,hot⟩ := ResidualChange.residual_witness least top pos dirty (v i) ((eq i i).symm.trans yes)
  obtain ⟨e,_,reps⟩ := Finset.mem_image.mp (shape ▸ m : s(p,q) ∈ edgeSet tri v)
  refine ⟨e,?_⟩
  rcases Sym2.eq_iff.mp reps with ⟨rfl,rfl⟩|⟨rfl,rfl⟩
  · exact ⟨⟨fun h => pu (congrArg v h.symm), fun h => qu (congrArg v h.symm)⟩,(eq _ _).trans hot⟩
  · have swap (x y : Fin n) : pairInput x y=pairInput y x := by funext z; simp only [pairInput]; grind
    rw [swap] at hot
    exact ⟨⟨fun h => qu (congrArg v h.symm), fun h => pu (congrArg v h.symm)⟩,(eq _ _).trans hot⟩

theorem charge (four : NoFourCycle G) (least : IsLeastAO G C) (top : TopForm G C)
    (empty : centreless G C=∅) (twoOr : (orN G C \ lam G C).card=2) {j h : ℕ} (eqJ : junk G C={j,h})
    (tri : Bool) (v : V→Fin n) (inj : Function.Injective v) (res : residual tri G C v)
    (m : M) (a b : Bool) (eq0 : ∀ p q,d0 m p q=ChartPhysical.Vg v C j p q)
    (eq1 : ∀ p q,d1 m a b p q=ChartPhysical.Vg v C h p q) : BothTable.guard tri m a b=true := by
  cases tri
  · rfl
  · simp only [BothTable.guard,Bool.not_true,Bool.false_or,Bool.not_eq_true',Bool.eq_false_iff]
    intro bad
    simp only [Bool.and_eq_true,Bool.not_eq_true'] at bad
    obtain ⟨⟨⟨yes,q1⟩,q2⟩,q4⟩ := bad
    let leaves : Finset (Fin n) := {v 1,v 2,v 4}
    have select (t : Fin n) (mt : t∈leaves) :
        s(v 0,t)∈Ustar G C ∧ gateVal n C j (pairInput (v 0) t)=false := by
      simp only [leaves,Finset.mem_insert,Finset.mem_singleton] at mt
      rcases mt with rfl|rfl|rfl
      · exact ⟨res 0,(eq0 0 1).symm.trans q1⟩
      · exact ⟨res 1,(eq0 0 2).symm.trans q2⟩
      · exact ⟨res 2,(eq0 0 4).symm.trans q4⟩
    have cost := BranchCharge.count_later_ors four least top empty eqJ (v 0) ((eq1 0 0).symm.trans yes) leaves
      (fun z hz => (select z hz).1) (fun z hz => (select z hz).2)
    have cap := Finset.card_le_card (Finset.filter_subset (fun m : ℕ => h < m) (orN G C \ lam G C))
    have three : leaves.card=3 := by simp [leaves,inj.ne (by decide : (1 : V)≠2),inj.ne (by decide : (1 : V)≠4),inj.ne (by decide : (2 : V)≠4)]
    omega

/-- Both visible exceptional ORs turn a physical counterexample into a member
    of the finite six-vertex search space, at the graph's actual coloring. -/
theorem realize (four : NoFourCycle G) (bip : G.IsBipartite) (least : IsLeastAO G C)
    (top : TopForm G C) (empty : centreless G C=∅) (two : (junk G C).card=2)
    (twoOr : (orN G C \ lam G C).card=2) (visible : ActiveOr.atTops G C=orN G C \ lam G C)
    (tri : Bool) (v : V→Fin n) (inj : Function.Injective v) (shape : Ustar G C=edgeSet tri v) :
    ∃ m a b flip, passes tri flip m a b=true := by
  classical
  have res := each shape
  obtain ⟨flip,col,align⟩ := chart bip tri v res
  obtain ⟨j,h,lt,eqJ⟩ := ChartPhysical.sorted_pair two
  let Raws := ChartPhysical.supports n C j h
  let m := fun i => ChartPhysical.rb v (Raws i)
  have jj : j∈junk G C := by simp [eqJ]
  have hh : h∈junk G C := by simp [eqJ]
  have atPort {g : ℕ} (mem : g∈junk G C) (b : Fin 2) : SixGeometry.RawOK G C (side (n:=n) C g b) := by
    have len := (junkData mem).1
    have bound := opndBound least.1 len b
    exact SixGeometry.actual_raw least.1 empty visible _ (by omega)
  have ok (i : Fin 4) : SixGeometry.RawOK G C (Raws i) := by
    fin_cases i
    · exact atPort jj 0
    · exact atPort jj 1
    · exact atPort hh 0
    · exact atPort hh 1
  obtain ⟨a,b,e0,e1⟩ := ChartPhysical.gates v least.1 top lt eqJ
  refine ⟨m,a,b,flip,accept tri flip m a b (fun i => Bool.and_eq_true_iff.mpr
    ⟨raw_mono v col align _ (ok i),raw_siblings four tri v inj res _ (ok i)⟩)
    (essential least top jj tri v shape _ e0) (essential least top hh tri v shape _ e1)
    (charge four least top empty twoOr eqJ tri v inj res m a b e0 e1) (fun i => ?_)⟩
  obtain ⟨k,yes,safe⟩ := ChartTops.actual_win v least top eqJ m a b e0 e1 (edges tri i) (res i)
  exact ⟨k,yes,fun p q on => upper four v inj res col align Raws ok p q (safe p q on)⟩
#print axioms realize
end BothBridge
