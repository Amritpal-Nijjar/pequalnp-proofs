import StarLeafBudget
import OrdinaryStar
import GeneralThree

namespace StarWire
open PEqualNP.CircuitLowerBounds PEqualNP.TopForm PEqualNP.EdgeOwnership
open PEqualNP.MetaComplexity.NestedCover PEqualNP.CleanedNonEdge
open PEqualNP.Outside.L_meta_7465_aux PEqualNP.Outside.L_meta_7465_aux.Routing
variable {n : ℕ} {G : SimpleGraph (Fin n)} [DecidableRel G.Adj] {C : Circuit}

/-- The nonempty residual star requires at least one more counted gate than
its number of edges. The visible exceptional OR and the hidden ones play
different roles in this estimate. -/
theorem star_cost (four : NoFourCycle G) (least : IsLeastAO G C) (top : TopForm G C)
    (empty : centreless G C = ∅) (nonempty : (Ustar G C).Nonempty)
    (v : Fin n) (center : ∀ e∈Ustar G C, v∈e) :
    (Ustar G C).card + 1 ≤ (junk G C).card + (orN G C \ lam G C).card := by
  classical
  let L : Finset (Fin n) := Finset.univ.filter (fun l => s(v,l) ∈ Ustar G C)
  have res (l : Fin n) (mem : l∈L) : s(v,l)∈Ustar G C := (Finset.mem_filter.mp mem).2
  have all : Ustar G C ⊆ L.image (fun l => s(v,l)) := by
    intro e mem
    obtain ⟨l,rfl⟩ := Sym2.mem_iff_exists.mp (center e mem)
    exact Finset.mem_image.mpr ⟨l,Finset.mem_filter.mpr ⟨Finset.mem_univ _,mem⟩,rfl⟩
  have size := (Finset.card_le_card all).trans Finset.card_image_le
  have leaf := StarLeafBudget.leaf_bound four least top empty v center L res
  have visible := ActiveOr.atTops_nonempty least empty nonempty
  have sub : ActiveOr.atTops G C ⊆ orN G C \ lam G C := Finset.filter_subset _ _
  have split := Finset.card_sdiff_add_card_eq_card sub
  change (StarLeafBudget.hidden G C).card + (ActiveOr.atTops G C).card = (orN G C \ lam G C).card at split
  have pos := Finset.card_pos.mpr visible
  omega

/-- With a centerless top, all exceptional ORs can be charged. That top
already contributes two units to the project's gate accounting inequality. -/
theorem star_cost_all (four : NoFourCycle G) (least : IsLeastAO G C) (top : TopForm G C)
    (nonempty : (Ustar G C).Nonempty) (v : Fin n) (center : ∀ e∈Ustar G C, v∈e) :
    (Ustar G C).card + 1 ≤ 2*(centreless G C).card + (junk G C).card + (orN G C \ lam G C).card := by
  classical
  by_cases empty : centreless G C = ∅
  · simpa [empty] using star_cost four least top empty nonempty v center
  let L : Finset (Fin n) := Finset.univ.filter (fun l => s(v,l) ∈ Ustar G C)
  have res (l : Fin n) (mem : l∈L) : s(v,l)∈Ustar G C := (Finset.mem_filter.mp mem).2
  have all : Ustar G C ⊆ L.image (fun l => s(v,l)) := by
    intro e mem
    obtain ⟨l,rfl⟩ := Sym2.mem_iff_exists.mp (center e mem)
    exact Finset.mem_image.mpr ⟨l,Finset.mem_filter.mpr ⟨Finset.mem_univ _,mem⟩,rfl⟩
  have size := (Finset.card_le_card all).trans Finset.card_image_le
  have leaf := StarLeafBudget.leaf_bound_of_control four least top _ Finset.Subset.rfl
    (OrdinaryStar.raw_control least.1) v center L res
  have positive := Finset.card_pos.mpr (Finset.nonempty_iff_ne_empty.mpr empty)
  omega

private theorem matching_one (S : Finset (Fin n)) (f : S → Fin n) (inj : Function.Injective f)
    (partners : ∀ i, f i ∉ S ∧ G.Adj i.val (f i)) (v : Fin n) (center : ∀ e∈Ustar G C, v∈e) :
    (GeneralThree.matchingEdges S f ∩ Ustar G C).card ≤ 1 := by
  classical
  apply Finset.card_le_one.mpr
  intro e he g hg
  obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp (Finset.mem_inter.mp he).1
  obtain ⟨j,_,rfl⟩ := Finset.mem_image.mp (Finset.mem_inter.mp hg).1
  have a := Sym2.mem_iff.mp (center _ (Finset.mem_inter.mp he).2)
  have b := Sym2.mem_iff.mp (center _ (Finset.mem_inter.mp hg).2)
  have eq : i=j := by
    rcases a with a|a <;> rcases b with b|b
    · exact Subtype.ext (a.symm.trans b)
    · exact ((partners j).1 ((a.symm.trans b) ▸ i.2)).elim
    · exact ((partners i).1 ((b.symm.trans a) ▸ j.2)).elim
    · exact inj (a.symm.trans b)
  subst j
  rfl

/-- For an arbitrary matching the repeated-wire-read bound of L-meta-17625
holds for any nonempty residual star. Gate counts and star size are unrestricted. -/
theorem star_wire_bound (four : NoFourCycle G) (least : IsLeastAO G C) (top : TopForm G C)
    (nonempty : (Ustar G C).Nonempty)
    (v : Fin n) (center : ∀ e∈Ustar G C, v∈e)
    (S : Finset (Fin n)) (f : S→Fin n) (inj : Function.Injective f)
    (partners : ∀ i, f i∉S ∧ G.Adj i.val (f i)) :
    GeneralThree.wireBound G C S := by
  classical
  have edges : G.edgeFinset.Nonempty := by
    obtain ⟨e,mem⟩ := nonempty
    exact ⟨e,(Finset.mem_sdiff.mp mem).1⟩
  have positive : 0 < C.size := by
    obtain ⟨e,mem⟩ := nonempty
    induction e using Sym2.ind with
    | h a b =>
      obtain ⟨_,_,_,j,hj,_,_⟩ := PEqualNP.Outside.L_meta_8005.residualTrace least top mem
      have inside : j<C.size := (junkData hj).1
      omega
  apply ResidualDegree.repeat_of_size G C least.1 positive
  obtain ⟨count, old⟩ := PEqualNP.Outside.L_meta_1491 n G C four edges least top
  obtain ⟨K,hK⟩ := ResidualDegree.min_cover_exists (G.deleteEdges ↑(Ustar G C))
  have retained := old K hK
  have matching := GeneralThree.matching_after_deletion G (Ustar G C) S f inj partners K hK.1
  have cap := matching_one S f inj partners v center
  have cost := star_cost_all four least top nonempty v center
  omega

#print axioms star_cost
#print axioms star_cost_all
#print axioms star_wire_bound
end StarWire
