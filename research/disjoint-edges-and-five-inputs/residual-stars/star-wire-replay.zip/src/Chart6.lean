import SixTerms
namespace Chart6
abbrev V := Fin 6
abbrev E := V × V
abbrev M := Fin 4 → V → Bool
def L (e : E) := e.1
def R (e : E) := e.2
def edges (tri : Bool) : Fin 4 → E := ![(0,1),(0,2),(if tri then 0 else 3,4),(3,5)]
def lit (s : V→Bool) (p q : V) := s p || s q
def d0 (m : M) (p q : V) := lit (m 0) p q && lit (m 1) p q
def d1 (m : M) (a b : Bool) (p q : V) :=
  (lit (m 2) p q || (a && d0 m p q)) && (lit (m 3) p q || (b && d0 m p q))
def vert (u p q : V) := decide (u=p ∨ u=q)
def sig (m : M) (a b d : Bool) := if d then d1 m a b else d0 m
def term (m : M) (a b : Bool) (e : E) (k : Fin 5) (p q : V) :=
  match k.val with
  | 0 => d0 m p q && vert (L e) p q
  | 1 => d0 m p q && vert (R e) p q
  | 2 => d1 m a b p q && vert (L e) p q
  | 3 => d1 m a b p q && vert (R e) p q
  | _ => d0 m p q && d1 m a b p q
def all6 (f : V→Bool) := f 0 && f 1 && f 2 && f 3 && f 4 && f 5
theorem all6_iff (f : V→Bool) : all6 f=true ↔ ∀ i, f i=true := by
  simp only [all6,Bool.and_eq_true]
  constructor
  · rintro ⟨⟨⟨⟨⟨a,b⟩,c⟩,d⟩,e⟩,g⟩ i; fin_cases i <;> assumption
  · intro h; exact ⟨⟨⟨⟨⟨h 0,h 1⟩,h 2⟩,h 3⟩,h 4⟩,h 5⟩
end Chart6
