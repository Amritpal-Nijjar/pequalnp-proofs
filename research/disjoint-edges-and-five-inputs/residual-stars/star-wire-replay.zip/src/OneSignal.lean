import ChartPhysical
import VisibleSignal4
import StarCenters
import StarRawGlue
namespace OneSignal
open PEqualNP.CircuitLowerBounds PEqualNP.TopForm PEqualNP.EdgeOwnership
open PEqualNP.MetaComplexity.NestedCover PEqualNP.CleanedNonEdge
open PEqualNP.Outside.L_meta_7465_aux PEqualNP.Outside.L_meta_7465_aux.Routing
open Chart6
variable {n : ℕ} {G : SimpleGraph (Fin n)} [DecidableRel G.Adj] {C : Circuit}
def port (C : Circuit) (j k : ℕ) : Fin 4→ℕ := ![opnd C j 0,opnd C j 1,opnd C k 0,opnd C k 1]
def masks (v : V→Fin n) (C : Circuit) (j k : ℕ) : M := fun i => ChartPhysical.rb v (ChartPhysical.supports n C j k i)
theorem masks_eq (v : V→Fin n) (C : Circuit) (j k : ℕ) :
    masks v C j k = fun i p => decide (v p∈orIn n C (port C j k i)) := by
  funext i p; fin_cases i <;> rfl
theorem port_bound (ao : IsAO2 n C) {j k : ℕ} (eqJ : junk G C={j,k}) :
    ∀ i, port C j k i < n+C.gates.length := by
  have jm : j∈junk G C := by simp [eqJ]
  have km : k∈junk G C := by simp [eqJ]
  have bd {g : ℕ} (mem : g∈junk G C) (b : Fin 2) : opnd C g b < n+C.gates.length := by
    have l := (junkData mem).1; have t := opndBound ao l b; omega
  intro i; fin_cases i
  · exact bd jm 0
  · exact bd jm 1
  · exact bd km 0
  · exact bd km 1

theorem projected (ao : IsAO2 n C) (top : TopForm G C) {h j k : ℕ}
    (seen : h∈ActiveOr.atTops G C) (lt : j<k) (pair : junk G C={j,k}) (v : V→Fin n)
    {w : Fin n} (raw : orIn n C (n+h)={w}) (avoid : ∀ i,v i≠w) :
    ∃ a b r s : Bool, ∀ p q, HiddenStarCert.signal (masks v C j k) a b r s p q =
      gateVal n C h (pairInput (v p) (v q)) := by
  classical
  let m := masks v C j k
  obtain ⟨a,b,dj,dk⟩ := ChartPhysical.gates v ao top lt pair
  let reach (g : ℕ) := decide (OrReaches n C (n+h) g)
  refine ⟨a,b,reach j,reach k,fun p q => ?_⟩
  apply Bool.eq_iff_iff.mpr
  change ((reach j && d0 m p q) || (reach k && d1 m a b p q))=true ↔ _
  rw [VisibleSignal4.pair_signal ao top seen raw (avoid p) (avoid q)]
  simp only [Bool.or_eq_true,Bool.and_eq_true,reach,decide_eq_true_eq,pair,
    Finset.mem_insert,Finset.mem_singleton]
  rw [show d0 m p q = ChartPhysical.Vg v C j p q from dj p q,
      show d1 m a b p q = ChartPhysical.Vg v C k p q from dk p q]
  constructor
  · rintro (⟨r,on⟩|⟨r,on⟩)
    · exact ⟨j,Or.inl rfl,r,on⟩
    · exact ⟨k,Or.inr rfl,r,on⟩
  · rintro ⟨g,rfl|rfl,r,on⟩
    · exact Or.inl ⟨r,on⟩
    · exact Or.inr ⟨r,on⟩

theorem graph_off {u v : Fin n} (no : ¬G.Adj u v) : graphFun G ∅ (pairInput u v)=false :=
  Bool.eq_false_iff.mpr (fun yes => no ((graphFun_pair G u v).mp yes))

/-- Two disjoint branching pairs suffice. Other residual edges are allowed. -/
theorem no_two_stars_single (four : NoFourCycle G) (bip : G.IsBipartite) (least : IsLeastAO G C)
    (top : TopForm G C) (empty : centreless G C=∅) (two : (junk G C).card=2)
    (twoOr : (orN G C \ lam G C).card=2) {h : ℕ} (one : ActiveOr.atTops G C={h})
    (v : V→Fin n) (inj : Function.Injective v) (e1 : s(v 0,v 1)∈Ustar G C)
    (e2 : s(v 0,v 2)∈Ustar G C) (e4 : s(v 3,v 4)∈Ustar G C) (e5 : s(v 3,v 5)∈Ustar G C) : False := by
  classical
  obtain ⟨w,only,wa,wd⟩ := BranchCharge.single_raw_center four least empty one (inj.ne (by decide))
    (inj.ne (by decide)) (inj.ne (by decide)) e1 e2 e4 e5
  obtain ⟨z,other,za,zd,A,D⟩ := StarCenters.no_cross four least empty one (inj.ne (by decide))
    (inj.ne (by decide)) (inj.ne (by decide)) e1 e2 e4 e5
  have eq : z=w := Finset.singleton_inj.mp (other.symm.trans only)
  subst z
  have avoid (i : V) : v i≠w := by
    fin_cases i
    · exact za.symm
    · exact (A _ e1).1
    · exact (A _ e2).1
    · exact zd.symm
    · exact (D _ e4).1
    · exact (D _ e5).1
  have center : ¬G.Adj (v 0) (v 3) := by
    intro e; obtain ⟨col⟩ := bip
    have t := col.valid e; have a := col.valid (SimpleGraph.deleteEdges_adj.mp wa).1
    have b := col.valid (SimpleGraph.deleteEdges_adj.mp wd).1; omega
  have seen : h∈ActiveOr.atTops G C := one ▸ Finset.mem_singleton_self _
  obtain ⟨j,k,lt,pair⟩ := ChartPhysical.sorted_pair two
  let m := masks v C j k
  have raw : HiddenStarCert.raw m=true := by
    rw [show m = fun i p => decide (v p∈orIn n C (port C j k i)) from masks_eq v C j k]
    exact StarRawGlue.physical_masks least.1 empty twoOr one v _ (port_bound least.1 pair)
      (StarRawGlue.good_on_stars four bip v inj w (SimpleGraph.deleteEdges_adj.mp wa).1
        (SimpleGraph.deleteEdges_adj.mp wd).1 e1 e2 e4 e5)
  obtain ⟨a,b,r,s,signal⟩ := projected least.1 top seen lt pair v only avoid
  have mem : w∈orIn n C (n+h) := only ▸ Finset.mem_singleton_self _
  have atA {t : Fin n} (e : s(v 0,t)∈Ustar G C) := VisibleSignal4.center_test bip least empty one mem (SimpleGraph.deleteEdges_adj.mp wa).1 e
  have atD {t : Fin n} (e : s(v 3,t)∈Ustar G C) := VisibleSignal4.center_test bip least empty one mem (SimpleGraph.deleteEdges_adj.mp wd).1 e
  have offA (q : V) (no : ¬G.Adj (v 0) (v q)) := (atA e1).2 _ (pairInput_left _ _) (graph_off no)
  have offD (q : V) (no : ¬G.Adj (v 3) (v q)) := (atD e4).2 _ (pairInput_left _ _) (graph_off no)
  have tests : HiddenStarCert.tests (HiddenStarCert.signal m a b r s)=true := by
    simp only [HiddenStarCert.tests,Bool.and_eq_true,Bool.not_eq_true',show m = masks v C j k from rfl,signal]
    exact ⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨(atA e1).1,(atA e2).1⟩,(atD e4).1⟩,(atD e5).1⟩,offA 0 G.irrefl⟩,
      offD 3 G.irrefl⟩,offA 3 center⟩,offA 4 (D _ e4).2⟩,offA 5 (D _ e5).2⟩,offD 1 (A _ e1).2⟩,offD 2 (A _ e2).2⟩
  exact Bool.false_ne_true ((HiddenStarCert.impossible m a b r s).symm.trans (Bool.and_eq_true_iff.mpr ⟨raw,tests⟩))
#print axioms no_two_stars_single
end OneSignal
