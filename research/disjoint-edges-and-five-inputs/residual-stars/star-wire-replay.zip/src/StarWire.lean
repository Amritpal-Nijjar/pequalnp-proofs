import StarCore
import RemainingGeometry

namespace StarWire
open PEqualNP.CircuitLowerBounds PEqualNP.TopForm PEqualNP.EdgeOwnership
open PEqualNP.MetaComplexity.NestedCover PEqualNP.CleanedNonEdge
open PEqualNP.Outside.L_meta_7465_aux PEqualNP.Outside.L_meta_7465_aux.Routing
variable {n : ℕ} {G : SimpleGraph (Fin n)} [DecidableRel G.Adj] {C : Circuit}

/-- The four-edge shape left by the preceding day's classification cannot
occur with exactly two dirty ANDs, two exceptional ORs and no centerless top. -/
theorem no_four_residual (four : NoFourCycle G) (bip : G.IsBipartite)
    (least : IsLeastAO G C) (top : TopForm G C) (empty : centreless G C=∅)
    (two : (junk G C).card=2) (twoOr : (orN G C \ lam G C).card=2) :
    (Ustar G C).card ≠ 4 := by
  intro card
  obtain ⟨v,center⟩ := RemainingGeometry.common_center four bip least top empty two twoOr card
  have nonempty := Finset.card_pos.mp (show 0 < (Ustar G C).card by omega)
  have cost := star_cost four least top empty nonempty v center
  omega

#print axioms no_four_residual
end StarWire
