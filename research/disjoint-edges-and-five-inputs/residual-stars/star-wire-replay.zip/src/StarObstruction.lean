import StarCore

namespace StarObstruction
open PEqualNP.CircuitLowerBounds PEqualNP.TopForm
open PEqualNP.MetaComplexity.NestedCover
variable {n : ℕ} {G : SimpleGraph (Fin n)} [DecidableRel G.Adj] {C : Circuit}

/-- A nonempty pairwise-intersecting family of graph edges in a bipartite
graph has a common vertex. The only alternative in a simple graph is a triangle. -/
theorem common_of_intersection (bip : G.IsBipartite) (U : Finset (Sym2 (Fin n)))
    (edges : U⊆G.edgeFinset) (ne : U.Nonempty)
    (meet : ∀ e∈U, ∀ g∈U, ∃ z, z∈e ∧ z∈g) :
    ∃ v : Fin n, ∀ e∈U, v∈e := by
  classical
  by_cases two : 1 < U.card
  · obtain ⟨e,he,f,hf,ef⟩ := Finset.one_lt_card.mp two
    obtain ⟨z,ze,zf⟩ := meet e he f hf
    obtain ⟨p,rfl⟩ := Sym2.mem_iff_exists.mp ze
    obtain ⟨q,rfl⟩ := Sym2.mem_iff_exists.mp zf
    refine ⟨z,fun g hg => ?_⟩
    by_contra absent
    obtain ⟨x,xg,xe⟩ := meet g hg _ he
    obtain ⟨y,yg,yf⟩ := meet g hg _ hf
    have xp : x=p := (Sym2.mem_iff.mp xe).resolve_left (fun eq => absent (eq ▸ xg))
    have yq : y=q := (Sym2.mem_iff.mp yf).resolve_left (fun eq => absent (eq ▸ yg))
    subst x
    subst y
    have pq : p≠q := fun eq => ef (eq ▸ rfl)
    have sg := (Sym2.mem_and_mem_iff pq).mp ⟨xg,yg⟩
    subst g
    obtain ⟨col⟩ := bip
    have c₁ : col z ≠ col p := col.valid (SimpleGraph.mem_edgeFinset.mp (edges he))
    have c₂ : col z ≠ col q := col.valid (SimpleGraph.mem_edgeFinset.mp (edges hf))
    have c₃ : col p ≠ col q := col.valid (SimpleGraph.mem_edgeFinset.mp (edges hg))
    omega
  · obtain ⟨e,he⟩ := ne
    induction e using Sym2.ind with
    | h a b =>
      refine ⟨a, fun g hg => ?_⟩
      have eq := Finset.card_le_one.mp (Nat.le_of_not_gt two) g hg _ he
      exact eq ▸ Sym2.mem_mk_left a b

/-- Even the empty residual gives the wire bound when the graph and circuit
are nonempty, as they are under the parent step's hypotheses. -/
theorem empty_wire (four : NoFourCycle G) (least : IsLeastAO G C) (top : TopForm G C)
    (edges : G.edgeFinset.Nonempty) (pos : 0<C.size) (empty : Ustar G C = ∅)
    (S : Finset (Fin n)) (f : S→Fin n) (inj : Function.Injective f)
    (partners : ∀ i, f i∉S ∧ G.Adj i.val (f i)) : GeneralThree.wireBound G C S := by
  classical
  obtain ⟨count,old⟩ := PEqualNP.Outside.L_meta_1491 n G C four edges least top
  obtain ⟨K,hK⟩ := ResidualDegree.min_cover_exists (G.deleteEdges ↑(Ustar G C))
  have retained := old K hK
  have matching := GeneralThree.matching_after_deletion G (Ustar G C) S f inj partners K hK.1
  simp only [empty,Finset.inter_empty,Finset.card_empty,Nat.add_zero] at count matching
  apply ResidualDegree.repeat_of_size G C least.1 pos
  omega

/-- Any failure of the repeated-read bound must have two vertex-disjoint
residual edges, regardless of the number or arrangement of circuit gates. -/
theorem failure_forces_disjoint (four : NoFourCycle G) (bip : G.IsBipartite)
    (least : IsLeastAO G C) (top : TopForm G C) (edges : G.edgeFinset.Nonempty)
    (pos : 0<C.size) (S : Finset (Fin n)) (f : S→Fin n) (inj : Function.Injective f)
    (partners : ∀ i, f i∉S ∧ G.Adj i.val (f i)) (failure : ¬GeneralThree.wireBound G C S) :
    ∃ e∈Ustar G C, ∃ g∈Ustar G C, ∀ v∈e, v∉g := by
  classical
  by_contra impossible
  have nonempty : (Ustar G C).Nonempty := by
    by_contra none
    exact failure (empty_wire four least top edges pos (Finset.not_nonempty_iff_eq_empty.mp none)
      S f inj partners)
  have meet (e) (he : e∈Ustar G C) (g) (hg : g∈Ustar G C) : ∃ v, v∈e ∧ v∈g := by
    by_contra absent
    exact impossible ⟨e,he,g,hg,fun v ve vg => absent ⟨v,ve,vg⟩⟩
  obtain ⟨v,center⟩ := common_of_intersection bip (Ustar G C) Finset.sdiff_subset nonempty meet
  exact failure (StarWire.star_wire_bound four least top nonempty v center S f inj partners)

#print axioms failure_forces_disjoint
end StarObstruction
