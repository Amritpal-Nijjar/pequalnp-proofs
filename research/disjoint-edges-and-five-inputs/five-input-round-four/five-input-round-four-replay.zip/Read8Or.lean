import Atlas8Or
namespace FiveOne.Read8Or
open PEqualNP.Outside.L_meta_12108 FiveSAT FiveStrictLate FiveLateModel
set_option maxRecDepth 100000
set_option maxHeartbeats 25000000
def realizes (u1 u2 u3 : Step) (word : ℕ) : Prop :=
  ∀r : Fin 32, prefixBit [u1,u2,u3] 8 (row r)=word.testBit r.val
lemma from0 (u1 u2 u3 : Step) (h : Atlas8Or.word0 u1 u2 u3=true) : realizes u1 u2 u3 2863180456 := by
  simp only [Atlas8Or.word0,Bool.and_eq_true_iff,Bool.not_eq_true'] at h
  rcases h with ⟨v0,v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,v12,v13,v14,v15,v16,v17,v18,v19,v20,v21,v22,v23,v24,v25,v26,v27,v28,v29,v30,v31,_⟩
  intro r
  fin_cases r
  · change prefixBit [u1,u2,u3] 8 0=false;rw [Atlas8Or.link0];exact v0
  · change prefixBit [u1,u2,u3] 8 1=false;rw [Atlas8Or.link1];exact v1
  · change prefixBit [u1,u2,u3] 8 2=false;rw [Atlas8Or.link2];exact v2
  · change prefixBit [u1,u2,u3] 8 3=true;rw [Atlas8Or.link3];exact v3
  · change prefixBit [u1,u2,u3] 8 4=false;rw [Atlas8Or.link4];exact v4
  · change prefixBit [u1,u2,u3] 8 5=true;rw [Atlas8Or.link5];exact v5
  · change prefixBit [u1,u2,u3] 8 6=false;rw [Atlas8Or.link6];exact v6
  · change prefixBit [u1,u2,u3] 8 7=true;rw [Atlas8Or.link7];exact v7
  · change prefixBit [u1,u2,u3] 8 8=false;rw [Atlas8Or.link8];exact v8
  · change prefixBit [u1,u2,u3] 8 9=true;rw [Atlas8Or.link9];exact v9
  · change prefixBit [u1,u2,u3] 8 10=false;rw [Atlas8Or.link10];exact v10
  · change prefixBit [u1,u2,u3] 8 11=true;rw [Atlas8Or.link11];exact v11
  · change prefixBit [u1,u2,u3] 8 12=false;rw [Atlas8Or.link12];exact v12
  · change prefixBit [u1,u2,u3] 8 13=true;rw [Atlas8Or.link13];exact v13
  · change prefixBit [u1,u2,u3] 8 14=false;rw [Atlas8Or.link14];exact v14
  · change prefixBit [u1,u2,u3] 8 15=true;rw [Atlas8Or.link15];exact v15
  · change prefixBit [u1,u2,u3] 8 16=false;rw [Atlas8Or.link16];exact v16
  · change prefixBit [u1,u2,u3] 8 17=false;rw [Atlas8Or.link17];exact v17
  · change prefixBit [u1,u2,u3] 8 18=false;rw [Atlas8Or.link18];exact v18
  · change prefixBit [u1,u2,u3] 8 19=true;rw [Atlas8Or.link19];exact v19
  · change prefixBit [u1,u2,u3] 8 20=false;rw [Atlas8Or.link20];exact v20
  · change prefixBit [u1,u2,u3] 8 21=true;rw [Atlas8Or.link21];exact v21
  · change prefixBit [u1,u2,u3] 8 22=false;rw [Atlas8Or.link22];exact v22
  · change prefixBit [u1,u2,u3] 8 23=true;rw [Atlas8Or.link23];exact v23
  · change prefixBit [u1,u2,u3] 8 24=false;rw [Atlas8Or.link24];exact v24
  · change prefixBit [u1,u2,u3] 8 25=true;rw [Atlas8Or.link25];exact v25
  · change prefixBit [u1,u2,u3] 8 26=false;rw [Atlas8Or.link26];exact v26
  · change prefixBit [u1,u2,u3] 8 27=true;rw [Atlas8Or.link27];exact v27
  · change prefixBit [u1,u2,u3] 8 28=false;rw [Atlas8Or.link28];exact v28
  · change prefixBit [u1,u2,u3] 8 29=true;rw [Atlas8Or.link29];exact v29
  · change prefixBit [u1,u2,u3] 8 30=false;rw [Atlas8Or.link30];exact v30
  · change prefixBit [u1,u2,u3] 8 31=true;rw [Atlas8Or.link31];exact v31
lemma from1 (u1 u2 u3 : Step) (h : Atlas8Or.word1 u1 u2 u3=true) : realizes u1 u2 u3 3233857664 := by
  simp only [Atlas8Or.word1,Bool.and_eq_true_iff,Bool.not_eq_true'] at h
  rcases h with ⟨v0,v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,v12,v13,v14,v15,v16,v17,v18,v19,v20,v21,v22,v23,v24,v25,v26,v27,v28,v29,v30,v31,_⟩
  intro r
  fin_cases r
  · change prefixBit [u1,u2,u3] 8 0=false;rw [Atlas8Or.link0];exact v0
  · change prefixBit [u1,u2,u3] 8 1=false;rw [Atlas8Or.link1];exact v1
  · change prefixBit [u1,u2,u3] 8 2=false;rw [Atlas8Or.link2];exact v2
  · change prefixBit [u1,u2,u3] 8 3=false;rw [Atlas8Or.link3];exact v3
  · change prefixBit [u1,u2,u3] 8 4=false;rw [Atlas8Or.link4];exact v4
  · change prefixBit [u1,u2,u3] 8 5=false;rw [Atlas8Or.link5];exact v5
  · change prefixBit [u1,u2,u3] 8 6=false;rw [Atlas8Or.link6];exact v6
  · change prefixBit [u1,u2,u3] 8 7=true;rw [Atlas8Or.link7];exact v7
  · change prefixBit [u1,u2,u3] 8 8=false;rw [Atlas8Or.link8];exact v8
  · change prefixBit [u1,u2,u3] 8 9=false;rw [Atlas8Or.link9];exact v9
  · change prefixBit [u1,u2,u3] 8 10=false;rw [Atlas8Or.link10];exact v10
  · change prefixBit [u1,u2,u3] 8 11=false;rw [Atlas8Or.link11];exact v11
  · change prefixBit [u1,u2,u3] 8 12=false;rw [Atlas8Or.link12];exact v12
  · change prefixBit [u1,u2,u3] 8 13=false;rw [Atlas8Or.link13];exact v13
  · change prefixBit [u1,u2,u3] 8 14=true;rw [Atlas8Or.link14];exact v14
  · change prefixBit [u1,u2,u3] 8 15=true;rw [Atlas8Or.link15];exact v15
  · change prefixBit [u1,u2,u3] 8 16=false;rw [Atlas8Or.link16];exact v16
  · change prefixBit [u1,u2,u3] 8 17=false;rw [Atlas8Or.link17];exact v17
  · change prefixBit [u1,u2,u3] 8 18=false;rw [Atlas8Or.link18];exact v18
  · change prefixBit [u1,u2,u3] 8 19=false;rw [Atlas8Or.link19];exact v19
  · change prefixBit [u1,u2,u3] 8 20=false;rw [Atlas8Or.link20];exact v20
  · change prefixBit [u1,u2,u3] 8 21=false;rw [Atlas8Or.link21];exact v21
  · change prefixBit [u1,u2,u3] 8 22=true;rw [Atlas8Or.link22];exact v22
  · change prefixBit [u1,u2,u3] 8 23=true;rw [Atlas8Or.link23];exact v23
  · change prefixBit [u1,u2,u3] 8 24=false;rw [Atlas8Or.link24];exact v24
  · change prefixBit [u1,u2,u3] 8 25=false;rw [Atlas8Or.link25];exact v25
  · change prefixBit [u1,u2,u3] 8 26=false;rw [Atlas8Or.link26];exact v26
  · change prefixBit [u1,u2,u3] 8 27=false;rw [Atlas8Or.link27];exact v27
  · change prefixBit [u1,u2,u3] 8 28=false;rw [Atlas8Or.link28];exact v28
  · change prefixBit [u1,u2,u3] 8 29=false;rw [Atlas8Or.link29];exact v29
  · change prefixBit [u1,u2,u3] 8 30=true;rw [Atlas8Or.link30];exact v30
  · change prefixBit [u1,u2,u3] 8 31=true;rw [Atlas8Or.link31];exact v31
def allowed : List ℕ := [2863180456,3233857664]
theorem literal_tables (u1 u2 u3 : Step) (h : boundaryBits true (prefixBit [u1,u2,u3] 8)=true) :
    ∃ word∈allowed, realizes u1 u2 u3 word := by
  have yes:=Atlas8Or.classified u1 u2 u3 h
  simp only [Atlas8Or.catalog,Bool.or_eq_true_iff,Bool.false_eq_true,or_false] at yes
  rcases yes with h|h
  · exact ⟨2863180456,by decide,from0 u1 u2 u3 h⟩
  · exact ⟨3233857664,by decide,from1 u1 u2 u3 h⟩
#print axioms literal_tables
end FiveOne.Read8Or
