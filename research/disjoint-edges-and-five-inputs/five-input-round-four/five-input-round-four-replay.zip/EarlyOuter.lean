import MixedOuter

namespace FiveRoundThree
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Outside.L_meta_12108
open FiveInputLower Five18096Finite

def earlyWord (inner outer : Bool) (i j k : Fin 5) : Sig :=
  prime outer (prime inner (atom i) (atom j)) (atom k)

private def pureCandidates (i j k : Fin 5) : List Sig :=
  [false,true].flatMap fun op =>
    ([(i,i,i),(j,j,j),(k,k,k),(i,j,j),(i,k,k),(j,k,k),(i,j,k)] :
      List (Fin 5 × Fin 5 × Fin 5)).map fun t => earlyWord op op t.1 t.2.1 t.2.2

def earlyAllowed : List Sig :=
  [earlyWord true false 1 2 0,earlyWord true false 1 3 0,earlyWord true false 2 3 0]

private def qneg : List Row := [6,10,12,17,18,20,24]
private def qpos : List Row := [3,5,9,14,22,26,28]
private def testOuter (mode : Bool) (B : Sig) : Bool :=
  if mode then qneg.all (fun r => !(bit r B)) else qpos.all (fun r => bit r B)

private theorem rawTriple (d : Bool) (i j k : Fin 5) :
    PureJoin (earlyWord d d i j k) ∨ PureMeet (earlyWord d d i j k) := by
  cases d with
  | false =>
    right; refine ⟨{i,j,k},?_⟩
    intro r
    simp [earlyWord,bit_prime,and_assoc]
  | true =>
    left; refine ⟨{i,j,k},?_⟩
    intro r
    simp [earlyWord,bit_prime,or_assoc]

private theorem catalog_pure (i j k : Fin 5) {B : Sig} (mem : B∈pureCandidates i j k) :
    PureJoin B ∨ PureMeet B := by
  obtain ⟨d,_,ds⟩ := List.mem_flatMap.mp mem
  obtain ⟨⟨x,y,z⟩,_,eq⟩ := List.mem_map.mp ds
  subst B
  exact rawTriple d x y z

private theorem recordedPos : ∀ r : Row, r∈qpos → bit r fiveGraph=true := by decide +kernel
private theorem recordedNeg : ∀ r : Row, r∈qneg → bit r fiveGraph=false := by decide +kernel
private theorem test_of_output (d : Bool) (G A B : Sig)
    (res : fiveGraph=combine3 d G A B) : testOuter d B=true := by
  have row (r : Row) : bit r fiveGraph=tailBits d (!(bit r G)) (bit r A) (bit r B) := by
    conv_lhs => rw [res]
    unfold combine3
    rw [bit_prime,bit_prime,saved_bit_neg]
    cases d <;> rfl
  cases d with
  | false =>
    apply List.all_eq_true.mpr
    intro r hr
    have eq := row r
    cases b : bit r B with
    | true => rfl
    | false => simp [tailBits,b,recordedPos r hr] at eq
  | true =>
    apply List.all_eq_true.mpr
    intro r hr
    have eq := row r
    cases b : bit r B with
    | false => simp [b]
    | true => simp [tailBits,b,recordedNeg r hr] at eq

set_option maxRecDepth 65000 in
set_option maxHeartbeats 0 in
private theorem early_cases : ∀ (d e t : Bool) (i j k : Fin 5),
    testOuter d (earlyWord e t i j k)=true →
      earlyWord e t i j k ∈ pureCandidates i j k ∨
      (d=true ∧ earlyWord e t i j k ∈ earlyAllowed) := by decide +kernel

/-- With arbitrary earlier wiring, an outer operand constructed in two binary
gates from raw inputs leaves only three truth functions and forces a final OR. -/
theorem two_gate_outer {C : Circuit} (h : Qualifies C) (p : List Gate) (n q f : Gate)
    (sp : C.gates=p++[n,q,f]) (op : n.op=.not) (inner : 5≤n.inputs.headD 0)
    (A : Sig) (e t : Bool) (i j k : Fin 5)
    (res : fiveGraph=combine3 (mode f) (src p n) A (earlyWord e t i j k)) :
    mode f=true ∧ earlyWord e t i j k∈earlyAllowed := by
  obtain ⟨nj,nm⟩ := mixed_outer h p n q f sp op inner A _ res
  rcases early_cases (mode f) e t i j k (test_of_output _ _ _ _ res) with fail|ok
  · exact ((catalog_pure i j k fail).elim nj nm).elim
  · exact ok

#print axioms two_gate_outer
end FiveRoundThree
