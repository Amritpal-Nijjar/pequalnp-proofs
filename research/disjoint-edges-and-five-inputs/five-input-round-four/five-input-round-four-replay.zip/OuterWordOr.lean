import Read8Or
import OneBoundaryCoverage
namespace FiveOne
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Outside.L_meta_12108
open FiveInputLower Five18096Finite FiveSAT FiveRoundThree FiveStrictLate
open FiveLateModel (Step)

theorem classify_wire_eight_or (ss : List Step) (len : ss.length=6) 
    (h : boundaryBits true (outerRow pre ss (enc 8))=true) :
    ∃ word ∈ Read8Or.allowed,
      ∀r : Fin 32, outerRow pre ss (enc 8) (row r)=word.testBit r.val := by
  cases ss with
  | nil => simp at len
  | cons u1 t =>
    cases t with
    | nil => simp at len
    | cons u2 t =>
      cases t with
      | nil => simp at len
      | cons u3 tail =>
        have eq : outerRow pre (u1::u2::u3::tail) (enc 8)=prefixBit [u1,u2,u3] 8 :=
          cut_suffix [u1,u2,u3] tail (by decide) (by simp) (by decide)
        rw [eq] at h ⊢
        exact Read8Or.literal_tables u1 u2 u3 h
#print axioms classify_wire_eight_or
end FiveOne
