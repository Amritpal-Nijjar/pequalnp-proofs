import LateShape

namespace FiveRoundThree
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Outside.L_meta_12108
open FiveInputLower Five18096Fresh Five18096Ends Five18096Finite Five18096Bypass Five18096Paths FiveRestricted

/-- Wire 11, the final ordinary wire before an eighth-position NOT, must appear
in an effective slot of one of the three remaining gates. -/
theorem final_prefix_use {C : Circuit} (h : Qualifies C) (p : List Gate) (n q f : Gate)
    (sp : C.gates=p++[n,q,f]) (op : n.op=.not) :
    n.inputs.headD 0=11 ∨ 11∈q.inputs ∨ 11∈f.inputs := by
  have sz := size_exact h
  have pl : p.length=7 := by simp [sp] at sz;omega
  rcases List.eq_nil_or_concat p with e | ⟨pre,z,e⟩
  · simp [e] at pl
  · have ep : p=pre++[z] := by simpa using e
    have six : pre.length=6 := by simp [ep] at pl;omega
    have split : C.gates=pre++z::[n,q,f] := by simpa [ep,List.append_assoc] using sp
    obtain ⟨r,rm,pin⟩ := effective_use h pre [n,q,f] z split (by simp [six,final_output h])
    have member : 11∈effective r := by simpa [six] using pin
    rcases List.mem_cons.mp rm with eqn|rm
    · subst r
      left
      have mem : 11 ∈ n.inputs.take 1 := by simpa [effective,isNot,op] using member
      cases ee : n.inputs with
      | nil => simp [ee] at mem
      | cons i rest => simpa [ee] using (show 11=i from by simpa [ee] using mem).symm
    · rcases List.mem_cons.mp rm with eqq|rm
      · subst r
        exact Or.inr (Or.inl (pins_subset q member))
      · have eq := List.mem_singleton.mp rm
        subst r
        exact Or.inr (Or.inr (pins_subset f member))

theorem one_of_pins {q : Gate} (valid : GValid q) {i a j : Nat}
    (mi : i∈q.inputs) (ma : a∈q.inputs) (ne : a≠i) (mj : j∈q.inputs) : j=i ∨ j=a := by
  obtain ⟨x,y,eqs,_⟩ := valid.2.2
  simp only [eqs,List.mem_cons,List.not_mem_nil,or_false] at mi ma mj
  omega

#print axioms final_prefix_use
end FiveRoundThree
