import SmallBool
import Base3
namespace FiveFixed3
open FiveSAT FiveLateModel FiveSmallKernel
set_option maxRecDepth 150000
set_option maxHeartbeats 12000000
set_option linter.unusedSimpArgs false
theorem noFinal11Or (u3 u4 u5 : Step) (l r g a : Select) : check u3 u4 u5 (⟨l,r,true⟩ : Step) g a (⟨true,true,false,true⟩ : Select) false=false := by
  simp only [check,expr1,expr3,expr6,expr9,expr10,expr14,expr18,expr20,expr22,expr26,Bool.false_eq_true,↓reduceIte,ite_self,Bool.not_true,Bool.not_false,Bool.and_false,Bool.false_and,Bool.or_false,Bool.false_or,Bool.and_true,Bool.true_and,Bool.or_true,Bool.true_or,selectTF,selectFT,selectXF,selectTX,selectFX,selectXT,beq_true,beq_false,Bool.true_beq,Bool.false_beq,Bool.not_not] <;> kernel_bool_sat
#print axioms noFinal11Or
end FiveFixed3
