import OrderedPhysical
import OneBase
namespace FiveOne
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Outside.L_meta_12108
open FiveInputLower Five18096Finite FiveSAT FiveRoundThree FiveStrictLate
open FiveLateModel (Step applyStep internalGet)

def prefixBit (ss : List Step) (b : ℕ) (r : Row) :=
  (ss.foldl applyStep ((execute pre fiveInputs).map (bit r))).getD b false

lemma grow_bits (s : List Step) (w : List Bool) : ∃ x,s.foldl applyStep w=w++x := by
  induction s generalizing w with
  | nil => exact ⟨[],by simp⟩
  | cons a s ih =>
    obtain ⟨x,shape⟩:=ih (applyStep w a)
    change ∃ _,s.foldl applyStep (applyStep w a)=_
    rw [shape];unfold applyStep
    exact ⟨_,List.append_assoc ..⟩

lemma length_bits (s : List Step) (w : List Bool) : (s.foldl applyStep w).length=w.length+s.length := by
  induction s generalizing w with
  | nil => simp
  | cons a s ih => simp [List.foldl_cons,ih,applyStep,Nat.add_assoc,Nat.add_comm 1]

lemma read_internal_bool (w : List Bool) {i : ℕ} (low : 5 ≤ i) (bound : i<w.length) (cap : i<16) :
    internalGet w (enc i)=w.getD i false := by
  rw [internalGet,mux_enc ⟨i,cap⟩]
  simp [show ¬i<5 by omega,List.getD_eq_getElem?_getD,List.getElem?_eq_getElem bound]

theorem cut_suffix (early later : List Step) {i : ℕ} (lo : 5 ≤ i) (hi : i<6+early.length) (cap : i<16) :
    outerRow pre (early++later) (enc i)=prefixBit early i := by
  funext r
  let w:=early.foldl applyStep ((execute pre fiveInputs).map (bit r))
  have wlen : w.length=6+early.length := by rw [show w=_ from rfl,length_bits];rfl
  have small : i<w.length := by omega
  obtain ⟨x,ext⟩:=grow_bits later w
  unfold outerRow prefixBit
  rw [List.foldl_append]
  change internalGet (later.foldl applyStep w) (enc i)=w.getD i false
  rw [ext,read_internal_bool _ lo (by simp;omega) cap]
  simp [List.getD_eq_getElem?_getD,List.getElem?_append_left small]
#print axioms cut_suffix
end FiveOne
