import ActualSelectors
namespace FiveStrictLate
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Outside.L_meta_12108
open FiveInputLower Five18096Fresh Five18096Ends Five18096Finite FiveRestricted FiveRoundThree FiveSAT
open FiveLateModel (Step get applyStep read_own)

def selLess (a b : Select) : Bool :=
  if a.b3 != b.b3 then b.b3 else
  if a.b2 != b.b2 then b.b2 else
  if a.b1 != b.b1 then b.b1 else (!a.b0) && b.b0

theorem selLess_enc : ∀ i j : Fin 16, selLess (enc i.val) (enc j.val)=decide (i<j) := by decide +kernel
def validStep (limit : ℕ) (u : Step) := selLess u.left u.right && lowerOK u.right limit
def ordered : ℕ → List Step → Bool
  | _,[] => true
  | k,g::gs => validStep k g && ordered (k+1) gs

lemma sorted_step (w : List Sig) (g : Gate) (legal : GValid g)
    (back : ∀ i∈g.inputs,i<w.length) (cap : w.length≤15) :
    ∃ u : Step, validStep w.length u=true ∧
      ∀ r : Row, applyStep (w.map (bit r)) u=(w++[gv w g]).map (bit r) := by
  obtain ⟨a,b,pins,ne⟩:=legal.2.2
  have al:=back a (by simp [pins])
  have bl:=back b (by simp [pins])
  have value:=FiveSAT.pair_value w g a b pins (Five18096Bypass.legal_ao g legal.1 legal.2.1)
  have ltval (s t : ℕ) (st:s<t) (tb:t<w.length) :
      validStep w.length ⟨enc s,enc t,FiveSAT.isOr g⟩=true := by
    have x:=selLess_enc ⟨s,by omega⟩ ⟨t,by omega⟩
    change selLess (enc s) (enc t)=decide (s<t) at x
    have y:=FiveSAT.bound_enc t w.length (show t<16 by omega)
    simp only [validStep,x,y,decide_eq_true st,decide_eq_true tb]
    rfl
  rcases lt_or_gt_of_ne ne with lt|gt
  · refine ⟨⟨enc a,enc b,FiveSAT.isOr g⟩,ltval a b lt bl,?_⟩
    intro r
    simp [applyStep,read_own w r al (by omega),read_own w r bl (by omega),value,bit_prime]
  · refine ⟨⟨enc b,enc a,FiveSAT.isOr g⟩,ltval b a gt al,?_⟩
    intro r
    simp [applyStep,read_own w r al (by omega),read_own w r bl (by omega),value,bit_prime,Bool.and_comm,Bool.or_comm]

theorem sorted_grow (gs : List Gate) (w : List Sig) (valid : ∀ g∈gs,GValid g) (back : Back w.length gs)
    (cap : w.length+gs.length≤15) :
    ∃ steps : List Step, steps.length=gs.length ∧ ordered w.length steps=true ∧
      ∀r : Row, steps.foldl applyStep (w.map (bit r))=(execute gs w).map (bit r) := by
  induction gs generalizing w with
  | nil => exact ⟨[],rfl,rfl,fun _=>rfl⟩
  | cons g gs ih =>
    obtain ⟨t,tv,teq⟩:=sorted_step w g (valid g (by simp)) back.1 (by omega)
    obtain ⟨ts,l,c,e⟩:=ih (w++[gv w g]) (fun q hq=>valid q (by simp [hq]))
      (by simpa using back.2) (by simp at cap ⊢;omega)
    refine ⟨t::ts,by simp [l],by simpa [ordered,tv] using c,?_⟩
    intro r;rw [List.foldl_cons,teq r,e];rfl
#print axioms sorted_grow
end FiveStrictLate
