import SortedPrefix
import LivePins
import OuterBoundary
namespace FiveStrictLate
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Outside.L_meta_12108
open FiveInputLower Five18096Fresh Five18096Ends Five18096Finite FiveRestricted FiveRoundThree FiveSAT
open FiveLateModel (Step applyStep grow read_internal internalGet)
def negativeBlocks : List (Row × List Row) :=
  [(6,[7,14,22]),(10,[11,14,26]),(12,[13,14,28]),(17,[19,21,25]),
   (18,[19,22,26]),(20,[21,22,28]),(24,[25,26,28])]
def positiveBlocks : List (Row × List Row) :=
  [(3,[2,1]),(5,[4,1]),(9,[8,1]),(14,[12,10,6]),(22,[20,18,6]),
   (26,[24,18,10]),(28,[24,20,12])]
def boundaryBits (d : Bool) (observe : Row→Bool) :=
  if d then negativeBlocks.all (fun p=> !(observe p.1)) && negativeBlocks.any (fun p=>p.2.all observe)
  else positiveBlocks.all (fun p=>observe p.1) && positiveBlocks.any (fun p=>p.2.all fun u=> !(observe u))
theorem boundary_bits_sig (d : Bool) (B : Sig) : boundaryBits d (fun r=>bit r B)=boundaryFilter d B := by
  cases d <;> rfl
def outerRow (pre : List Gate) (ss : List Step) (b : Select) (r : Row) :=
  internalGet (ss.foldl applyStep ((execute pre fiveInputs).map (bit r))) b
theorem physical_filters {C : Circuit} (h : Qualifies C) (pre mid : List Gate) (n q f : Gate)
    (sp : C.gates=pre++(mid++[n,q,f])) (op : n.op=.not) (inner : 5≤n.inputs.headD 0) :
    ∃(ss : List Step) (g a b : ℕ) (d : Bool), ss.length=mid.length ∧ d=mode f ∧
      5≤g ∧ g<12 ∧ 5≤a ∧ a<12 ∧ 5≤b ∧ b<12 ∧ g≠a ∧ g≠b ∧ a≠b ∧
      (g=11 ∨ a=11 ∨ b=11) ∧ ordered (5+pre.length) ss=true ∧
      boundaryBits d (outerRow pre ss (enc b))=true ∧
      ∀r : Row,rowPass pre ss (enc g) (enc a) (enc b) d r=true := by
  let p := pre++mid
  let w := execute pre fiveInputs
  have e : C.gates=p++[n,q,f] := by simpa [p,List.append_assoc] using sp
  obtain ⟨a,b,live,_,_,al,as,bl,bs,ga,gb,ab,output,_⟩:=live_internal_shape h p n q f e op inner
  obtain ⟨_,_,_,_,_,gs,_,_,_⟩:=late_shape h p n q f e op inner
  have sz:=size_exact h
  have plen : p.length=7 := by simp [e] at sz;omega
  have bounds := back_of_index 5 C.gates h.back
  rw [sp] at bounds
  have preBack := (back_split pre (mid++[n,q,f]) 5 bounds).2
  have mb := (back_split mid [n,q,f] _ preBack).1
  have lw : w.length=5+pre.length := by unfold w;rw [execute_len];rfl
  have all := (no_other_not C p [q,f] n e op (exactCounts C h.legal h.cap h.computes h.internal).2.1).1
  have valid (g) (hg : g∈mid) : GValid g := by
    have hm : g∈C.gates := by simp [sp,hg]
    have no := all g (by simp [p,hg])
    exact ⟨(h.legal g hm).1,no,(filters h).binary g hm no⟩
  have pl : p.length=pre.length+mid.length := List.length_append
  obtain ⟨ss,l,ord,val⟩:=sorted_grow mid w valid (lw ▸ mb) (by omega)
  have gne (j : ℕ) (ne : src p n≠(execute p fiveInputs).getD j zero) : n.inputs.headD 0≠j := by
    intro eq; apply ne; unfold src;rw [eq]
  refine ⟨ss,n.inputs.headD 0,a,b,mode f,l,rfl,inner,by omega,al,by omega,bl,by omega,
    gne a ga,gne b gb,(by intro eq;apply ab;rw [eq]),live,lw ▸ ord,?_,?_⟩
  · have lenW : (execute p fiveInputs).length=5+p.length := by rw [execute_len];rfl
    have bank : outerRow pre ss (enc b)=fun r=>bit r ((execute p fiveInputs).getD b zero) := by
      funext r
      have W : execute mid w=execute p fiveInputs := (execute_append pre mid fiveInputs).symm
      change internalGet (ss.foldl applyStep (w.map (bit r))) (enc b)=_
      rw [val r,W,read_internal _ r bl (by omega) (by omega)]
    rw [bank,boundary_bits_sig]
    exact outer_boundary h p n q f e op inner _ _ output
  ·

    intro r
    have W : execute mid w=execute p fiveInputs := (execute_append pre mid fiveInputs).symm
    have length : (execute p fiveInputs).length=5+p.length := by rw [execute_len];rfl
    unfold rowPass
    change (finish (ss.foldl applyStep (w.map (bit r))) _ _ _ _ == _) = true
    rw [val r,W,finish,read_internal _ r inner (by omega) (by omega),
      read_internal _ r al (by omega) (by omega),read_internal _ r bl (by omega) (by omega),beq_iff_eq]
    conv_rhs => rw [output]
    unfold combine3 src
    rw [bit_prime,bit_prime,saved_bit_neg]
    cases mode f <;> rfl

#print axioms physical_filters
end FiveStrictLate
