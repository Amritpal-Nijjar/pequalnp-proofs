"""Run from the configured project with lake env python /path/to/replay.py."""
import json
import os
from pathlib import Path
import subprocess
import tempfile
root=Path(__file__).resolve().parent
modules=json.loads((root/"manifest.json").read_text(encoding="utf-8"))["modules"]
with tempfile.TemporaryDirectory(prefix="five-round4-") as s:
    work=Path(s)
    env=dict(os.environ)
    env.pop("SIX_CERT_GENERATE",None)
    env["LEAN_PATH"]=os.pathsep.join([str(work)]+[str(Path(p).resolve()) for p in env.get("LEAN_PATH","").split(os.pathsep) if p])
    for n in modules:
        print("Checking "+n,flush=True)
        subprocess.run(["lean","-j","1","-s","65536","-M","15000","-R",str(root),"-o",str(work/(n+".olean")),str(root/(n+".lean"))],env=env,check=True)
