import OneBase
import SmallBool
namespace FiveOne
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Outside.L_meta_12108
open FiveInputLower Five18096Finite FiveSAT FiveRoundThree FiveSmallKernel
open FiveLateModel (Step)
open FiveStrictLate (rowPass)
set_option maxRecDepth 170000
set_option maxHeartbeats 30000000
set_option linter.unusedSimpArgs false
def testOne5Or (u1 u2 u3 u4 u5 u6 : Step) (g a : Select) := triple g a (⟨true,false,true,false⟩ : Select) && (expr6 u1 u2 u3 u4 u5 u6 g a (⟨true,false,true,false⟩ : Select) true)
theorem refuteOne5Or (u1 u2 u3 u4 u5 u6 : Step) (g a : Select) : testOne5Or u1 u2 u3 u4 u5 u6 g a=false := by
  simp only [testOne5Or,triple,legalPin,sameSel,expr6,Bool.false_eq_true,↓reduceIte,ite_self,selectTF,selectFT,selectXF,selectTX,selectFX,selectXT,beq_true,beq_false,Bool.true_beq,Bool.false_beq,Bool.not_true,Bool.not_false,Bool.not_not,Bool.and_false,Bool.false_and,Bool.or_false,Bool.false_or,Bool.and_true,Bool.true_and,Bool.or_true,Bool.true_or] <;> kernel_small_sat
theorem noFitOne5Or (u1 u2 u3 u4 u5 u6 : Step) (g a : Select) : ¬fits u1 u2 u3 u4 u5 u6 g a (⟨true,false,true,false⟩ : Select) true := by
  rintro ⟨good,hit⟩
  have at6 : expr6 u1 u2 u3 u4 u5 u6 g a (⟨true,false,true,false⟩ : Select) true=true := by rw [←row6];exact hit 6
  have passes : testOne5Or u1 u2 u3 u4 u5 u6 g a=true := by simp [testOne5Or,good,at6]
  exact Bool.noConfusion (passes.symm.trans (refuteOne5Or u1 u2 u3 u4 u5 u6 g a))
#print axioms noFitOne5Or
end FiveOne
