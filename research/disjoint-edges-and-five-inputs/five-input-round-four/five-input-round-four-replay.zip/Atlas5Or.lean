import EarlyProjection
import SmallBool
namespace FiveOne.Atlas5Or
open PEqualNP.Outside.L_meta_12108 FiveSAT FiveStrictLate FiveSmallKernel
open FiveLateModel (Step)
set_option maxRecDepth 100000
set_option maxHeartbeats 25000000
set_option linter.unusedSimpArgs false
def row6  : Bool :=
  true
lemma link6  : prefixBit [] 5 6=row6 := rfl
def row7  : Bool :=
  true
lemma link7  : prefixBit [] 5 7=row7 := rfl
def row10  : Bool :=
  false
lemma link10  : prefixBit [] 5 10=row10 := rfl
def row11  : Bool :=
  false
lemma link11  : prefixBit [] 5 11=row11 := rfl
def row12  : Bool :=
  false
lemma link12  : prefixBit [] 5 12=row12 := rfl
def row13  : Bool :=
  false
lemma link13  : prefixBit [] 5 13=row13 := rfl
def row14  : Bool :=
  true
lemma link14  : prefixBit [] 5 14=row14 := rfl
def row17  : Bool :=
  false
lemma link17  : prefixBit [] 5 17=row17 := rfl
def row18  : Bool :=
  false
lemma link18  : prefixBit [] 5 18=row18 := rfl
def row19  : Bool :=
  false
lemma link19  : prefixBit [] 5 19=row19 := rfl
def row20  : Bool :=
  false
lemma link20  : prefixBit [] 5 20=row20 := rfl
def row21  : Bool :=
  false
lemma link21  : prefixBit [] 5 21=row21 := rfl
def row22  : Bool :=
  true
lemma link22  : prefixBit [] 5 22=row22 := rfl
def row24  : Bool :=
  false
lemma link24  : prefixBit [] 5 24=row24 := rfl
def row25  : Bool :=
  false
lemma link25  : prefixBit [] 5 25=row25 := rfl
def row26  : Bool :=
  false
lemma link26  : prefixBit [] 5 26=row26 := rfl
def row28  : Bool :=
  false
lemma link28  : prefixBit [] 5 28=row28 := rfl
def boundary  : Bool := (!(row6) && (!(row10) && (!(row12) && (!(row17) && (!(row18) && (!(row20) && (!(row24) && true))))))) && (((row7) && ((row14) && ((row22) && true))) || (((row11) && ((row14) && ((row26) && true))) || (((row13) && ((row14) && ((row28) && true))) || (((row19) && ((row21) && ((row25) && true))) || (((row19) && ((row22) && ((row26) && true))) || (((row21) && ((row22) && ((row28) && true))) || (((row25) && ((row26) && ((row28) && true))) || false)))))))
lemma transfer  : boundaryBits true (prefixBit [] 5)=boundary := by
  simp only [boundaryBits,negativeBlocks,positiveBlocks,List.all_cons,List.all_nil,List.any_cons,List.any_nil,Bool.false_eq_true,↓reduceIte,boundary,link6,link7,link10,link11,link12,link13,link14,link17,link18,link19,link20,link21,link22,link24,link25,link26,link28]
theorem refuted  : boundary=false := by
  simp only [boundary,row6,row7,row10,row11,row12,row13,row14,row17,row18,row19,row20,row21,row22,row24,row25,row26,row28,Bool.false_eq_true,↓reduceIte,ite_self,selectTF,selectFT,selectXF,selectTX,selectFX,selectXT,beq_true,beq_false,Bool.true_beq,Bool.false_beq,Bool.not_true,Bool.not_false,Bool.not_not,Bool.and_false,Bool.false_and,Bool.or_false,Bool.false_or,Bool.and_true,Bool.true_and,Bool.or_true,Bool.true_or] <;> kernel_small_sat
theorem classified  : boundaryBits true (prefixBit [] 5)=false := (transfer).trans (refuted)
#print axioms classified
end FiveOne.Atlas5Or
