import EarlyOuter

namespace FiveRoundThree
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Outside.L_meta_12108
open FiveInputLower Five18096Finite

private def negGroups : List (Row × List Row) :=
  [(6,[7,14,22]),(10,[11,14,26]),(12,[13,14,28]),(17,[19,21,25]),
   (18,[19,22,26]),(20,[21,22,28]),(24,[25,26,28])]
private def posGroups : List (Row × List Row) :=
  [(3,[2,1]),(5,[4,1]),(9,[8,1]),(14,[12,10,6]),(22,[20,18,6]),
   (26,[24,18,10]),(28,[24,20,12])]
set_option maxHeartbeats 0 in
private theorem coverNegative : ∀ t : Row, bit t fiveGraph=false → ∃ block∈negGroups,
    ∀ u∈block.2, rowLE t u ∧ bit u fiveGraph=true := by decide +kernel
set_option maxHeartbeats 0 in
private theorem coverPositive : ∀ r : Row, bit r fiveGraph=true → ∃ block∈posGroups,
    ∀ u∈block.2, rowLE u r ∧ bit u fiveGraph=false := by decide +kernel
private theorem negLabels : ∀ block∈negGroups, bit block.1 fiveGraph=false := by
  simp [negGroups]; decide +kernel
private theorem posLabels : ∀ block∈posGroups, bit block.1 fiveGraph=true := by
  simp [posGroups]; decide +kernel

def boundaryFilter (d : Bool) (B : Sig) : Bool :=
  if d then
    negGroups.all (fun p => !(bit p.1 B)) &&
    negGroups.any (fun p => p.2.all (fun u => bit u B))
  else
    posGroups.all (fun p => bit p.1 B) &&
    posGroups.any (fun p => p.2.all (fun u => !(bit u B)))

/-- The outer wire agrees with the target on one complete extremal boundary.
Every physical eighth-position inverter enforces this before any prefix is fixed. -/
theorem outer_boundary {C : Circuit} (h : Qualifies C) (p : List Gate) (n q f : Gate)
    (sp : C.gates=p++[n,q,f]) (op : n.op=.not) (inner : 5≤n.inputs.headD 0) (A B : Sig)
    (output : fiveGraph=combine3 (mode f) (src p n) A B) : boundaryFilter (mode f) B=true := by
  let G := src p n
  let d := mode f
  have row (r : Row) : bit r fiveGraph=tailBits d (!(bit r G)) (bit r A) (bit r B) := by
    conv_lhs => rw [output]
    unfold combine3
    rw [bit_prime,bit_prime,saved_bit_neg]
    cases e : mode f <;> simp [tailBits,d,e,G]
  obtain ⟨⟨r,fr,gr,_⟩,⟨t,ft,gt,_⟩⟩ := pivotal_rows h p [q,f] n sp op inner
  change bit r G=false at gr
  change bit t G=true at gt
  have mono {a b : Row} (le : rowLE a b) : bit a G=true → bit b G=true :=
    monotone_source h p [q,f] n sp op le
  change boundaryFilter d B=true
  cases flag : d with
  | true =>
    apply Bool.and_eq_true_iff.mpr
    constructor
    · apply List.all_eq_true.mpr
      intro b hb
      have eq := row b.1
      cases bb : bit b.1 B with
      | false => simp [bb]
      | true => simp [tailBits,flag,bb,negLabels b hb] at eq
    · obtain ⟨b,mem,all⟩ := coverNegative t ft
      apply List.any_eq_true.mpr
      refine ⟨b,mem,List.all_eq_true.mpr ?_⟩
      intro u hu
      obtain ⟨le,fu⟩ := all u hu
      simpa [tailBits,flag,mono le gt,fu] using (row u).symm
  | false =>
    apply Bool.and_eq_true_iff.mpr
    constructor
    · apply List.all_eq_true.mpr
      intro b hb
      have eq := row b.1
      cases bb : bit b.1 B with
      | true => rfl
      | false => simp [tailBits,flag,bb,posLabels b hb] at eq
    · obtain ⟨b,mem,all⟩ := coverPositive r fr
      apply List.any_eq_true.mpr
      refine ⟨b,mem,List.all_eq_true.mpr ?_⟩
      intro u hu
      obtain ⟨le,fu⟩ := all u hu
      have gu : bit u G=false := by
        cases eq : bit u G with
        | false => rfl
        | true => exact Bool.noConfusion (gr.symm.trans (mono le eq))
      have bu : bit u B=false := by simpa [tailBits,flag,gu,fu] using (row u).symm
      simp [bu]

set_option maxHeartbeats 0 in
set_option maxRecDepth 50000 in
theorem all_two_fail : ∀ (d e t : Bool) (i j k : Fin 5),
  boundaryFilter d (earlyWord e t i j k)=false := by decide +kernel

theorem outer_ne_two_gate {C : Circuit} (h : Qualifies C) (p : List Gate) (n q f : Gate)
    (sp : C.gates=p++[n,q,f]) (op : n.op=.not) (inner : 5≤n.inputs.headD 0)
    (A : Sig) (e t : Bool) (i j k : Fin 5) :
    fiveGraph ≠ combine3 (mode f) (src p n) A (earlyWord e t i j k) := by
  intro eq
  have pass := outer_boundary h p n q f sp op inner A _ eq
  exact Bool.noConfusion (pass.symm.trans (all_two_fail ..))

#print axioms outer_boundary
#print axioms outer_ne_two_gate
end FiveRoundThree
