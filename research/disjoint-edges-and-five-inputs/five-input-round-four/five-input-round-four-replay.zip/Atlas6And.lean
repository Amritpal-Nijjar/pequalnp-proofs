import EarlyProjection
import SmallBool
namespace FiveOne.Atlas6And
open PEqualNP.Outside.L_meta_12108 FiveSAT FiveStrictLate FiveSmallKernel
open FiveLateModel (Step)
set_option maxRecDepth 100000
set_option maxHeartbeats 25000000
set_option linter.unusedSimpArgs false
def row1 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else true)) else (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else true))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else true))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else true)) else (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else true))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else true))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link1 (u1 : Step) : prefixBit [u1] 6 1=row1 u1 := rfl
def row2 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then true else false))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then true else false))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link2 (u1 : Step) : prefixBit [u1] 6 2=row2 u1 := rfl
def row3 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else true)) else (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else true))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then true else true))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else true)) else (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else true))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then true else true))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link3 (u1 : Step) : prefixBit [u1] 6 3=row3 u1 := rfl
def row4 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else true) else (if u1.left.b0 then false else false))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else true) else (if u1.right.b0 then false else false))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link4 (u1 : Step) : prefixBit [u1] 6 4=row4 u1 := rfl
def row5 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else true)) else (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else true))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else true) else (if u1.left.b0 then false else true))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else true)) else (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else true))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else true) else (if u1.right.b0 then false else true))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link5 (u1 : Step) : prefixBit [u1] 6 5=row5 u1 := rfl
def row6 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then true else false)) else (if u1.left.b1 then (if u1.left.b0 then false else true) else (if u1.left.b0 then true else false))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then true else false)) else (if u1.right.b1 then (if u1.right.b0 then false else true) else (if u1.right.b0 then true else false))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link6 (u1 : Step) : prefixBit [u1] 6 6=row6 u1 := rfl
def row8 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then true else false) else (if u1.left.b0 then false else false))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then true else false) else (if u1.right.b0 then false else false))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link8 (u1 : Step) : prefixBit [u1] 6 8=row8 u1 := rfl
def row9 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else true)) else (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else true))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then true else false) else (if u1.left.b0 then false else true))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else true)) else (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else true))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then true else false) else (if u1.right.b0 then false else true))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link9 (u1 : Step) : prefixBit [u1] 6 9=row9 u1 := rfl
def row10 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then true else false) else (if u1.left.b0 then true else false))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then true else false) else (if u1.right.b0 then true else false))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link10 (u1 : Step) : prefixBit [u1] 6 10=row10 u1 := rfl
def row12 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then false else false))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then false else false))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link12 (u1 : Step) : prefixBit [u1] 6 12=row12 u1 := rfl
def row14 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then true else false)) else (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else false))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then true else false)) else (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else false))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link14 (u1 : Step) : prefixBit [u1] 6 14=row14 u1 := rfl
def row18 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else true)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then true else false))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else true)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then true else false))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link18 (u1 : Step) : prefixBit [u1] 6 18=row18 u1 := rfl
def row20 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else true)) else (if u1.left.b1 then (if u1.left.b0 then false else true) else (if u1.left.b0 then false else false))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else true)) else (if u1.right.b1 then (if u1.right.b0 then false else true) else (if u1.right.b0 then false else false))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link20 (u1 : Step) : prefixBit [u1] 6 20=row20 u1 := rfl
def row22 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then true else true)) else (if u1.left.b1 then (if u1.left.b0 then false else true) else (if u1.left.b0 then true else false))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then true else true)) else (if u1.right.b1 then (if u1.right.b0 then false else true) else (if u1.right.b0 then true else false))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link22 (u1 : Step) : prefixBit [u1] 6 22=row22 u1 := rfl
def row24 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else true)) else (if u1.left.b1 then (if u1.left.b0 then true else false) else (if u1.left.b0 then false else false))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else true)) else (if u1.right.b1 then (if u1.right.b0 then true else false) else (if u1.right.b0 then false else false))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link24 (u1 : Step) : prefixBit [u1] 6 24=row24 u1 := rfl
def row26 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else true)) else (if u1.left.b1 then (if u1.left.b0 then true else false) else (if u1.left.b0 then true else false))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else true)) else (if u1.right.b1 then (if u1.right.b0 then true else false) else (if u1.right.b0 then true else false))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link26 (u1 : Step) : prefixBit [u1] 6 26=row26 u1 := rfl
def row28 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else true)) else (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then false else false))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else true)) else (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then false else false))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link28 (u1 : Step) : prefixBit [u1] 6 28=row28 u1 := rfl
def boundary (u1 : Step) : Bool := ((row3 u1) && ((row5 u1) && ((row9 u1) && ((row14 u1) && ((row22 u1) && ((row26 u1) && ((row28 u1) && true))))))) && ((!(row2 u1) && (!(row1 u1) && true)) || ((!(row4 u1) && (!(row1 u1) && true)) || ((!(row8 u1) && (!(row1 u1) && true)) || ((!(row12 u1) && (!(row10 u1) && (!(row6 u1) && true))) || ((!(row20 u1) && (!(row18 u1) && (!(row6 u1) && true))) || ((!(row24 u1) && (!(row18 u1) && (!(row10 u1) && true))) || ((!(row24 u1) && (!(row20 u1) && (!(row12 u1) && true))) || false)))))))
lemma transfer (u1 : Step) : boundaryBits false (prefixBit [u1] 6)=boundary u1 := by
  simp only [boundaryBits,negativeBlocks,positiveBlocks,List.all_cons,List.all_nil,List.any_cons,List.any_nil,Bool.false_eq_true,↓reduceIte,boundary,link1,link2,link3,link4,link5,link6,link8,link9,link10,link12,link14,link18,link20,link22,link24,link26,link28]
theorem refuted (u1 : Step) : boundary u1=false := by
  simp only [boundary,row1,row2,row3,row4,row5,row6,row8,row9,row10,row12,row14,row18,row20,row22,row24,row26,row28,Bool.false_eq_true,↓reduceIte,ite_self,selectTF,selectFT,selectXF,selectTX,selectFX,selectXT,beq_true,beq_false,Bool.true_beq,Bool.false_beq,Bool.not_true,Bool.not_false,Bool.not_not,Bool.and_false,Bool.false_and,Bool.or_false,Bool.false_or,Bool.and_true,Bool.true_and,Bool.or_true,Bool.true_or] <;> kernel_small_sat
theorem classified (u1 : Step) : boundaryBits false (prefixBit [u1] 6)=false := (transfer u1).trans (refuted u1)
#print axioms classified
end FiveOne.Atlas6And
