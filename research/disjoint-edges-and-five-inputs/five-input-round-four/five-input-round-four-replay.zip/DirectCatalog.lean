import EarlyProjection
namespace FiveOne.DirectCatalog
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Outside.L_meta_12108
open FiveInputLower Five18096Fresh Five18096Finite Five18096Ends FiveSAT FiveRoundThree
set_option maxHeartbeats 0
set_option maxRecDepth 100000
def raw : List Sig := [226854911280625642308916404954512140970,272225893536750770770699685945414569164,320265757102059730318470218759311257840,338958311018522360492699998064329424640,340277174703306882242637262502835978240,256212605681647784254776175007449006272]
theorem raw_exact : execute pre fiveInputs=raw := by decide +kernel
def firstOptions : List Sig := [170808403787765189503184116671632670848,181483929024500513847133123963609712776,213510504734706486878980145839540838560,225972207345681573661799998709552949760,226851449802204588161758175001890652160,226854911280625642308916404954512140970,255215669472769777312150586777848037376,256208696247195770159162174119782383616,256212605681647784254776175007449006272,271166648814817888394159998451463539712,272221739762645505794109810002268782592,272225893536750770770699685945414569164,312259113174508237060508463290328476394,317596875792875899232482966936316997358,319019586840962221640188233472310046720,320260870308994712698952717649727979520,320265757102059730318470218759311257840,333610163647978885748406477874282560250,336279044957162716834393729697276820732,338953139004072225113288479380256849920,338958311018522360492699998064329424640,339841014953466429139816404309288615850,339955247227400367435325586293930393536,340017555740455242869239685558280454092,340204481279619869170981983351330635760,340277174703306882242637262502835978240,340280636181727936389795492455457467050,340281084137758896338251263390502600896,340281328477412147219227138445981764812,340282061496371899862154763612419256560,340282346717757017622048781186908552960]
def goodAnd : List ℕ := [4277993212,4293590954,4293722092,4294508536,4294961834]
def goodOr : List ℕ := [2863180456,3233857664]
def words (w : List Sig) := w.flatMap (fun a=>w.flatMap (fun b=>[prime false a b,prime true a b]))
def low32 (v : Sig) := v.toNat % 4294967296
def good (v : Sig) := ((!boundaryFilter false v) || goodAnd.contains (low32 v)) &&
                       ((!boundaryFilter true v) || goodOr.contains (low32 v))
def allFollowing (u : Sig) :=
  let w:=raw++[u]
  (words w).eraseDups.all (fun v=>(words (w++[v])).all good)
theorem first_covers : (words raw).all firstOptions.contains=true := by decide +kernel
theorem chunk0 : allFollowing (170808403787765189503184116671632670848 : Sig)=true := by decide +kernel
theorem chunk1 : allFollowing (181483929024500513847133123963609712776 : Sig)=true := by decide +kernel
theorem chunk2 : allFollowing (213510504734706486878980145839540838560 : Sig)=true := by decide +kernel
theorem chunk3 : allFollowing (225972207345681573661799998709552949760 : Sig)=true := by decide +kernel
theorem chunk4 : allFollowing (226851449802204588161758175001890652160 : Sig)=true := by decide +kernel
theorem chunk5 : allFollowing (226854911280625642308916404954512140970 : Sig)=true := by decide +kernel
theorem chunk6 : allFollowing (255215669472769777312150586777848037376 : Sig)=true := by decide +kernel
theorem chunk7 : allFollowing (256208696247195770159162174119782383616 : Sig)=true := by decide +kernel
theorem chunk8 : allFollowing (256212605681647784254776175007449006272 : Sig)=true := by decide +kernel
theorem chunk9 : allFollowing (271166648814817888394159998451463539712 : Sig)=true := by decide +kernel
theorem chunk10 : allFollowing (272221739762645505794109810002268782592 : Sig)=true := by decide +kernel
theorem chunk11 : allFollowing (272225893536750770770699685945414569164 : Sig)=true := by decide +kernel
theorem chunk12 : allFollowing (312259113174508237060508463290328476394 : Sig)=true := by decide +kernel
theorem chunk13 : allFollowing (317596875792875899232482966936316997358 : Sig)=true := by decide +kernel
theorem chunk14 : allFollowing (319019586840962221640188233472310046720 : Sig)=true := by decide +kernel
theorem chunk15 : allFollowing (320260870308994712698952717649727979520 : Sig)=true := by decide +kernel
theorem chunk16 : allFollowing (320265757102059730318470218759311257840 : Sig)=true := by decide +kernel
theorem chunk17 : allFollowing (333610163647978885748406477874282560250 : Sig)=true := by decide +kernel
theorem chunk18 : allFollowing (336279044957162716834393729697276820732 : Sig)=true := by decide +kernel
theorem chunk19 : allFollowing (338953139004072225113288479380256849920 : Sig)=true := by decide +kernel
theorem chunk20 : allFollowing (338958311018522360492699998064329424640 : Sig)=true := by decide +kernel
theorem chunk21 : allFollowing (339841014953466429139816404309288615850 : Sig)=true := by decide +kernel
theorem chunk22 : allFollowing (339955247227400367435325586293930393536 : Sig)=true := by decide +kernel
theorem chunk23 : allFollowing (340017555740455242869239685558280454092 : Sig)=true := by decide +kernel
theorem chunk24 : allFollowing (340204481279619869170981983351330635760 : Sig)=true := by decide +kernel
theorem chunk25 : allFollowing (340277174703306882242637262502835978240 : Sig)=true := by decide +kernel
theorem chunk26 : allFollowing (340280636181727936389795492455457467050 : Sig)=true := by decide +kernel
theorem chunk27 : allFollowing (340281084137758896338251263390502600896 : Sig)=true := by decide +kernel
theorem chunk28 : allFollowing (340281328477412147219227138445981764812 : Sig)=true := by decide +kernel
theorem chunk29 : allFollowing (340282061496371899862154763612419256560 : Sig)=true := by decide +kernel
theorem chunk30 : allFollowing (340282346717757017622048781186908552960 : Sig)=true := by decide +kernel
theorem complete : firstOptions.all allFollowing=true := by
  simp only [firstOptions,List.all_cons,List.all_nil,chunk0,chunk1,chunk2,chunk3,chunk4,chunk5,chunk6,chunk7,chunk8,chunk9,chunk10,chunk11,chunk12,chunk13,chunk14,chunk15,chunk16,chunk17,chunk18,chunk19,chunk20,chunk21,chunk22,chunk23,chunk24,chunk25,chunk26,chunk27,chunk28,chunk29,chunk30]
  rfl
lemma candidate (w : List Sig) (g : Gate) (valid : FiveRestricted.GValid g)
    (back : ∀i∈g.inputs,i<w.length) : gv w g∈words w := by
  obtain ⟨a,b,pins,ne⟩:=valid.2.2
  have ma := read_mem w a (back a (by simp [pins]))
  have mb := read_mem w b (back b (by simp [pins]))
  have eq:=pair_value w g a b pins (Five18096Bypass.legal_ao g valid.1 valid.2.1)
  apply List.mem_flatMap.mpr ⟨_,ma,?_⟩
  apply List.mem_flatMap.mpr ⟨_,mb,?_⟩
  cases h:isOr g <;> simp [eq,h]
theorem accepted (u v z : Sig) (hu : u∈words raw) (hv : v∈words (raw++[u]))
    (hz : z∈words ((raw++[u])++[v])) (d : Bool) (pass : boundaryFilter d z=true) :
    (if d then goodOr else goodAnd).contains (low32 z)=true := by
  have h1:=List.contains_iff_mem.mp (List.all_eq_true.mp first_covers u hu)
  have h2:=List.all_eq_true.mp complete u h1
  have h3 := List.all_eq_true.mp h2 v (by simpa using hv)
  have h4 := List.all_eq_true.mp h3 z hz
  cases d <;> simp_all [good]
#print axioms accepted
end FiveOne.DirectCatalog
