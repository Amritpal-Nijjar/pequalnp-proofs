import EarlyProjection
import SmallBool
namespace FiveOne.Atlas5And
open PEqualNP.Outside.L_meta_12108 FiveSAT FiveStrictLate FiveSmallKernel
open FiveLateModel (Step)
set_option maxRecDepth 100000
set_option maxHeartbeats 25000000
set_option linter.unusedSimpArgs false
def row1  : Bool :=
  false
lemma link1  : prefixBit [] 5 1=row1 := rfl
def row2  : Bool :=
  false
lemma link2  : prefixBit [] 5 2=row2 := rfl
def row3  : Bool :=
  false
lemma link3  : prefixBit [] 5 3=row3 := rfl
def row4  : Bool :=
  false
lemma link4  : prefixBit [] 5 4=row4 := rfl
def row5  : Bool :=
  false
lemma link5  : prefixBit [] 5 5=row5 := rfl
def row6  : Bool :=
  true
lemma link6  : prefixBit [] 5 6=row6 := rfl
def row8  : Bool :=
  false
lemma link8  : prefixBit [] 5 8=row8 := rfl
def row9  : Bool :=
  false
lemma link9  : prefixBit [] 5 9=row9 := rfl
def row10  : Bool :=
  false
lemma link10  : prefixBit [] 5 10=row10 := rfl
def row12  : Bool :=
  false
lemma link12  : prefixBit [] 5 12=row12 := rfl
def row14  : Bool :=
  true
lemma link14  : prefixBit [] 5 14=row14 := rfl
def row18  : Bool :=
  false
lemma link18  : prefixBit [] 5 18=row18 := rfl
def row20  : Bool :=
  false
lemma link20  : prefixBit [] 5 20=row20 := rfl
def row22  : Bool :=
  true
lemma link22  : prefixBit [] 5 22=row22 := rfl
def row24  : Bool :=
  false
lemma link24  : prefixBit [] 5 24=row24 := rfl
def row26  : Bool :=
  false
lemma link26  : prefixBit [] 5 26=row26 := rfl
def row28  : Bool :=
  false
lemma link28  : prefixBit [] 5 28=row28 := rfl
def boundary  : Bool := ((row3) && ((row5) && ((row9) && ((row14) && ((row22) && ((row26) && ((row28) && true))))))) && ((!(row2) && (!(row1) && true)) || ((!(row4) && (!(row1) && true)) || ((!(row8) && (!(row1) && true)) || ((!(row12) && (!(row10) && (!(row6) && true))) || ((!(row20) && (!(row18) && (!(row6) && true))) || ((!(row24) && (!(row18) && (!(row10) && true))) || ((!(row24) && (!(row20) && (!(row12) && true))) || false)))))))
lemma transfer  : boundaryBits false (prefixBit [] 5)=boundary := by
  simp only [boundaryBits,negativeBlocks,positiveBlocks,List.all_cons,List.all_nil,List.any_cons,List.any_nil,Bool.false_eq_true,↓reduceIte,boundary,link1,link2,link3,link4,link5,link6,link8,link9,link10,link12,link14,link18,link20,link22,link24,link26,link28]
theorem refuted  : boundary=false := by
  simp only [boundary,row1,row2,row3,row4,row5,row6,row8,row9,row10,row12,row14,row18,row20,row22,row24,row26,row28,Bool.false_eq_true,↓reduceIte,ite_self,selectTF,selectFT,selectXF,selectTX,selectFX,selectXT,beq_true,beq_false,Bool.true_beq,Bool.false_beq,Bool.not_true,Bool.not_false,Bool.not_not,Bool.and_false,Bool.false_and,Bool.or_false,Bool.false_or,Bool.and_true,Bool.true_and,Bool.or_true,Bool.true_or] <;> kernel_small_sat
theorem classified  : boundaryBits false (prefixBit [] 5)=false := (transfer).trans (refuted)
#print axioms classified
end FiveOne.Atlas5And
