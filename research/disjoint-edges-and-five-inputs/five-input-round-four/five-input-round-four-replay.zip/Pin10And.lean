import Base3
namespace FiveFixed3
open FiveSAT FiveLateModel
set_option maxRecDepth 150000
set_option maxHeartbeats 12000000
set_option linter.unusedSimpArgs false
theorem noPin10And (u3 u4 u5 u6 : Step) (g a : Select) :
    check u3 u4 u5 u6 g a (⟨false,true,false,true⟩ : Select) false=false := by
  simp only [check,expr1,expr3,expr6,expr9,expr10,expr14,expr18,expr20,expr22,expr26,Bool.false_eq_true,↓reduceIte,ite_self,Bool.not_true,Bool.not_false,Bool.and_false,Bool.false_and,Bool.or_false,Bool.false_or,Bool.and_true,Bool.true_and,Bool.or_true,Bool.true_or] <;> kernel_bool_sat
#print axioms noPin10And
end FiveFixed3
