import Mathlib.Tactic.Sat.FromLRAT
/-!
Kernel-checked RUP replay with proved intermediate clauses. The input parser,
clause reifier and individual RUP-step proof constructor are Mathlib's. Sharing
the larger subproofs as ordinary theorems bounds the size of each declaration.
-/
open Lean Meta
namespace FivePackedLRAT
open Mathlib.Tactic.Sat

def replay (cnf lrat : String) (name : Name) : MetaM (Nat × Expr × Expr × Expr) := do
  let .success _ (nvars, clauses) := Parser.parseDimacs ⟨_,cnf.startPos⟩
    | throwError "Could not parse DIMACS"
  if clauses.isEmpty then throwError "Empty input"
  let formulaValue := buildConj clauses 0 clauses.size
  let formulaName := name ++ `context
  addDecl <| .defnDecl {
    name:=formulaName,levelParams:=[],type:=mkConst ``Sat.Fmla,value:=formulaValue,
    hints:=.regular 0,safety:=.safe
  }
  let formula := mkConst formulaName
  let .success _ steps := Parser.parseLRAT ⟨_,lrat.startPos⟩
    | throwError "Could not parse LRAT"
  let mut uses : Std.HashMap Nat Nat := {}
  for s in steps do
    if let .add _ _ hints := s then
      for hint in hints do
        let k:=hint.natAbs
        uses:=uses.insert k (uses.getD k 0+1)
  let p:=mkApp (mkConst ``Sat.Fmla.subsumes_self) formula
  let mut db := (buildClauses clauses formula 0 clauses.size formulaValue p default).2
  let mut weights : Std.HashMap Nat Nat := {}
  let mut cuts := 0
  for s in steps do
    match s with
    | .del ids =>
      db:=ids.foldl (·.erase ·) db
      weights:=ids.foldl (·.erase ·) weights
    | .add i lits hints =>
      let e:=buildClause lits
      let .ok pr := buildProofStep db lits hints formula e | throwError "Invalid RUP step {i}"
      let weight:=hints.foldl (fun a k=>a+weights.getD k.natAbs 1) (1+hints.size)
      let cut:=lits.isEmpty || weight>400 || (uses.getD i 0>2 && weight>80)
      let pf ← if cut then do
        let aux:=Name.num (name ++ `rup) i
        addDecl <| .thmDecl {
          name := aux
          levelParams := []
          type := mkApp2 (mkConst ``Sat.Fmla.proof) formula e
          value := pr
        }
        pure (mkConst aux)
      else pure pr
      if cut then cuts:=cuts+1
      if lits.isEmpty then
        IO.println s!"LRAT checked through {cuts} intermediate theorems."
        return (nvars,formula,formulaValue,pf)
      db:=db.insert i {lits,expr:=e,proof:=pf}
      weights:=weights.insert i (if cut then 1 else weight)
  throwError "No empty clause"
end FivePackedLRAT
