import Final11And
import Final11Or
import Base3
namespace FiveFixed3
open FiveSAT FiveLateModel
set_option maxRecDepth 150000
set_option maxHeartbeats 12000000
set_option linter.unusedSimpArgs false
theorem noPin11And (u3 u4 u5 u6 : Step) (g a : Select) :
    check u3 u4 u5 u6 g a (⟨true,true,false,true⟩ : Select) false=false := by
  obtain ⟨l,r,d⟩:=u6
  cases d
  · exact noFinal11And u3 u4 u5 l r g a
  · exact noFinal11Or u3 u4 u5 l r g a
#print axioms noPin11And
end FiveFixed3
