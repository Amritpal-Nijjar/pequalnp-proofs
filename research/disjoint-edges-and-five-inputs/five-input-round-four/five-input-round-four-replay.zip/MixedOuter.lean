import LatePins

namespace FiveRoundThree
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.Outside.L_meta_12108
open FiveInputLower Five18096Fresh Five18096Ends Five18096Finite Five18096Bypass Five18096Paths FiveRestricted

def PureJoin (B : Sig) : Prop := ∃ K : Finset (Fin 5), ∀ r : Row,
  bit r B=true ↔ ∃ i∈K, bit r (atom i)=true
def PureMeet (B : Sig) : Prop := ∃ K : Finset (Fin 5), ∀ r : Row,
  bit r B=true ↔ ∀ i∈K, bit r (atom i)=true

private theorem cubeEnds : ∀ r : Row, rowLE 0 r ∧ rowLE r 31 := by decide +kernel

/-- For any eighth-position inverter, the outer input B in the alternating
final two gates is neither a conjunction nor a disjunction of raw inputs.
This permits any set of raw inputs, including the empty set. -/
theorem mixed_outer {C : Circuit} (h : Qualifies C) (p : List Gate) (n q f : Gate)
    (sp : C.gates=p++[n,q,f]) (op : n.op=.not) (inner : 5≤n.inputs.headD 0) (A B : Sig)
    (output : fiveGraph=combine3 (mode f) (src p n) A B) : ¬ PureJoin B ∧ ¬ PureMeet B := by
  let G := src p n
  let d := mode f
  have row (r : Row) : bit r fiveGraph=tailBits d (!(bit r G)) (bit r A) (bit r B) := by
    conv_lhs => rw [output]
    unfold combine3
    rw [bit_prime,bit_prime,saved_bit_neg]
    cases e : mode f <;> simp [tailBits,d,e,G]
  obtain ⟨⟨r,fr,gr,_⟩,⟨t,ft,gt,_⟩⟩ := pivotal_rows h p [q,f] n sp op inner
  change bit r G=false at gr
  change bit t G=true at gt
  have mono {a b : Row} (le : rowLE a b) : bit a G=true → bit b G=true :=
    monotone_source h p [q,f] n sp op le
  have neg {a b : Row} (le : rowLE a b) (bb : bit b G=false) : bit a G=false := by
    cases e : bit a G with
    | false => rfl
    | true => exact Bool.noConfusion (bb.symm.trans (mono le e))
  have j : ∃ u : Row, bit u B=true ∧ ∀ i : Fin 5, bit u (atom i)=true → bit (singleton i) B=false := by
    cases flag : d with
    | false =>
      refine ⟨r,?_,?_⟩
      · simpa [tailBits,flag,gr,fr] using (row r).symm
      · intro i mem
        have gc := neg ((cube_extrema i r).1 mem) gr
        have fc := (target_extrema i).2.2.1
        simpa [tailBits,flag,gc,fc] using (row (singleton i)).symm
    | true =>
      refine ⟨31,?_,?_⟩
      · have gc := mono (cubeEnds t).2 gt
        have fc := target_rises.2
        simpa [tailBits,flag,gc,fc] using (row 31).symm
      · intro i _
        have fc := (target_extrema i).2.2.1
        have eq := row (singleton i)
        cases bb : bit (singleton i) B with
        | false => rfl
        | true => simp [tailBits,flag,bb,fc] at eq
  have m : ∃ u : Row, bit u B=false ∧ ∀ i : Fin 5, bit u (atom i)=false → bit (cosingleton i) B=true := by
    cases flag : d with
    | false =>
      refine ⟨0,?_,?_⟩
      · have gc := neg (cubeEnds r).1 gr
        have fc := target_rises.1
        simpa [tailBits,flag,gc,fc] using (row 0).symm
      · intro i _
        have fc := (target_extrema i).2.2.2
        have eq := row (cosingleton i)
        cases bb : bit (cosingleton i) B with
        | true => rfl
        | false => simp [tailBits,flag,bb,fc] at eq
    | true =>
      refine ⟨t,?_,?_⟩
      · simpa [tailBits,flag,gt,ft] using (row t).symm
      · intro i mem
        have gc := mono ((cube_extrema i t).2 mem) gt
        have fc := (target_extrema i).2.2.2
        simpa [tailBits,flag,gc,fc] using (row (cosingleton i)).symm
  constructor
  · rintro ⟨K,H⟩
    obtain ⟨u,ub,small⟩ := j
    obtain ⟨i,ik,iu⟩ := (H u).mp ub
    have bad := (H (singleton i)).mpr ⟨i,ik,(target_extrema i).1⟩
    exact Bool.noConfusion ((small i iu).symm.trans bad)
  · rintro ⟨K,H⟩
    obtain ⟨u,ub,large⟩ := m
    have ok : bit u B=true := (H u).mpr (by
      intro i ik
      cases iu : bit u (atom i) with
      | true => rfl
      | false =>
        have bad := (H (cosingleton i)).mp (large i iu) i ik
        exact Bool.noConfusion (((target_extrema i).2.1).symm.trans bad))
    exact Bool.noConfusion (ub.symm.trans ok)

theorem raw_gate_pure (d : Bool) (i j : Fin 5) :
    PureJoin (prime d (atom i) (atom j)) ∨ PureMeet (prime d (atom i) (atom j)) := by
  cases d with
  | false =>
    right; refine ⟨{i,j},?_⟩
    intro r
    simp [bit_prime,Finset.forall_mem_insert]
  | true =>
    left; refine ⟨{i,j},?_⟩
    intro r
    simp [bit_prime]

theorem outer_not_single_raw_gate {C : Circuit} (h : Qualifies C) (p : List Gate) (n q f : Gate)
    (sp : C.gates=p++[n,q,f]) (op : n.op=.not) (inner : 5≤n.inputs.headD 0)
    (A : Sig) (v : Bool) (i j : Fin 5) :
    fiveGraph ≠ combine3 (mode f) (src p n) A (prime v (atom i) (atom j)) := by
  intro eq
  obtain ⟨noJ,noM⟩ := mixed_outer h p n q f sp op inner A _ eq
  exact (raw_gate_pure v i j).elim noJ noM

#print axioms mixed_outer
#print axioms outer_not_single_raw_gate
end FiveRoundThree
