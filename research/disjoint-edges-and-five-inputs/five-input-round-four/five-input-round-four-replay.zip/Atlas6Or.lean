import EarlyProjection
import SmallBool
namespace FiveOne.Atlas6Or
open PEqualNP.Outside.L_meta_12108 FiveSAT FiveStrictLate FiveSmallKernel
open FiveLateModel (Step)
set_option maxRecDepth 100000
set_option maxHeartbeats 25000000
set_option linter.unusedSimpArgs false
def row6 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then true else false)) else (if u1.left.b1 then (if u1.left.b0 then false else true) else (if u1.left.b0 then true else false))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then true else false)) else (if u1.right.b1 then (if u1.right.b0 then false else true) else (if u1.right.b0 then true else false))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link6 (u1 : Step) : prefixBit [u1] 6 6=row6 u1 := rfl
def row7 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else true)) else (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else true))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else false)) else (if u1.left.b1 then (if u1.left.b0 then false else true) else (if u1.left.b0 then true else true))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else true)) else (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else true))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else false)) else (if u1.right.b1 then (if u1.right.b0 then false else true) else (if u1.right.b0 then true else true))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link7 (u1 : Step) : prefixBit [u1] 6 7=row7 u1 := rfl
def row10 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then true else false) else (if u1.left.b0 then true else false))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then true else false) else (if u1.right.b0 then true else false))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link10 (u1 : Step) : prefixBit [u1] 6 10=row10 u1 := rfl
def row11 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else true)) else (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else true))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then true else false) else (if u1.left.b0 then true else true))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else true)) else (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else true))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then true else false) else (if u1.right.b0 then true else true))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link11 (u1 : Step) : prefixBit [u1] 6 11=row11 u1 := rfl
def row12 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then false else false))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then false else false))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link12 (u1 : Step) : prefixBit [u1] 6 12=row12 u1 := rfl
def row13 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else true)) else (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else true))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then false else true))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else true)) else (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else true))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then false else true))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link13 (u1 : Step) : prefixBit [u1] 6 13=row13 u1 := rfl
def row14 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then true else false)) else (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else false))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then true else false)) else (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else false))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link14 (u1 : Step) : prefixBit [u1] 6 14=row14 u1 := rfl
def row17 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else true)) else (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else true))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then false else true)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else true))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else true)) else (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else true))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then false else true)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else true))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link17 (u1 : Step) : prefixBit [u1] 6 17=row17 u1 := rfl
def row18 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else true)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then true else false))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else true)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then true else false))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link18 (u1 : Step) : prefixBit [u1] 6 18=row18 u1 := rfl
def row19 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else true)) else (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else true))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then false else true)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then true else true))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else true)) else (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else true))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then false else true)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then true else true))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link19 (u1 : Step) : prefixBit [u1] 6 19=row19 u1 := rfl
def row20 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else true)) else (if u1.left.b1 then (if u1.left.b0 then false else true) else (if u1.left.b0 then false else false))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else true)) else (if u1.right.b1 then (if u1.right.b0 then false else true) else (if u1.right.b0 then false else false))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link20 (u1 : Step) : prefixBit [u1] 6 20=row20 u1 := rfl
def row21 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else true)) else (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else true))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then false else true)) else (if u1.left.b1 then (if u1.left.b0 then false else true) else (if u1.left.b0 then false else true))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else true)) else (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else true))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then false else true)) else (if u1.right.b1 then (if u1.right.b0 then false else true) else (if u1.right.b0 then false else true))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link21 (u1 : Step) : prefixBit [u1] 6 21=row21 u1 := rfl
def row22 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then true else true)) else (if u1.left.b1 then (if u1.left.b0 then false else true) else (if u1.left.b0 then true else false))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then true else true)) else (if u1.right.b1 then (if u1.right.b0 then false else true) else (if u1.right.b0 then true else false))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link22 (u1 : Step) : prefixBit [u1] 6 22=row22 u1 := rfl
def row24 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else true)) else (if u1.left.b1 then (if u1.left.b0 then true else false) else (if u1.left.b0 then false else false))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else true)) else (if u1.right.b1 then (if u1.right.b0 then true else false) else (if u1.right.b0 then false else false))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link24 (u1 : Step) : prefixBit [u1] 6 24=row24 u1 := rfl
def row25 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else true)) else (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then true else true))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then false else true)) else (if u1.left.b1 then (if u1.left.b0 then true else false) else (if u1.left.b0 then false else true))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else true)) else (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then true else true))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then false else true)) else (if u1.right.b1 then (if u1.right.b0 then true else false) else (if u1.right.b0 then false else true))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link25 (u1 : Step) : prefixBit [u1] 6 25=row25 u1 := rfl
def row26 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else true)) else (if u1.left.b1 then (if u1.left.b0 then true else false) else (if u1.left.b0 then true else false))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else true)) else (if u1.right.b1 then (if u1.right.b0 then true else false) else (if u1.right.b0 then true else false))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link26 (u1 : Step) : prefixBit [u1] 6 26=row26 u1 := rfl
def row28 (u1 : Step) : Bool :=
  let l1 := (if u1.left.b3 then (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false)) else (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else false))) else (if u1.left.b2 then (if u1.left.b1 then (if u1.left.b0 then false else false) else (if u1.left.b0 then false else true)) else (if u1.left.b1 then (if u1.left.b0 then true else true) else (if u1.left.b0 then false else false))))
  let r1 := (if u1.right.b3 then (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false)) else (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else false))) else (if u1.right.b2 then (if u1.right.b1 then (if u1.right.b0 then false else false) else (if u1.right.b0 then false else true)) else (if u1.right.b1 then (if u1.right.b0 then true else true) else (if u1.right.b0 then false else false))))
  let v1 := if u1.op then l1||r1 else l1&&r1
  v1
lemma link28 (u1 : Step) : prefixBit [u1] 6 28=row28 u1 := rfl
def boundary (u1 : Step) : Bool := (!(row6 u1) && (!(row10 u1) && (!(row12 u1) && (!(row17 u1) && (!(row18 u1) && (!(row20 u1) && (!(row24 u1) && true))))))) && (((row7 u1) && ((row14 u1) && ((row22 u1) && true))) || (((row11 u1) && ((row14 u1) && ((row26 u1) && true))) || (((row13 u1) && ((row14 u1) && ((row28 u1) && true))) || (((row19 u1) && ((row21 u1) && ((row25 u1) && true))) || (((row19 u1) && ((row22 u1) && ((row26 u1) && true))) || (((row21 u1) && ((row22 u1) && ((row28 u1) && true))) || (((row25 u1) && ((row26 u1) && ((row28 u1) && true))) || false)))))))
lemma transfer (u1 : Step) : boundaryBits true (prefixBit [u1] 6)=boundary u1 := by
  simp only [boundaryBits,negativeBlocks,positiveBlocks,List.all_cons,List.all_nil,List.any_cons,List.any_nil,Bool.false_eq_true,↓reduceIte,boundary,link6,link7,link10,link11,link12,link13,link14,link17,link18,link19,link20,link21,link22,link24,link25,link26,link28]
theorem refuted (u1 : Step) : boundary u1=false := by
  simp only [boundary,row6,row7,row10,row11,row12,row13,row14,row17,row18,row19,row20,row21,row22,row24,row25,row26,row28,Bool.false_eq_true,↓reduceIte,ite_self,selectTF,selectFT,selectXF,selectTX,selectFX,selectXT,beq_true,beq_false,Bool.true_beq,Bool.false_beq,Bool.not_true,Bool.not_false,Bool.not_not,Bool.and_false,Bool.false_and,Bool.or_false,Bool.false_or,Bool.and_true,Bool.true_and,Bool.or_true,Bool.true_or] <;> kernel_small_sat
theorem classified (u1 : Step) : boundaryBits true (prefixBit [u1] 6)=false := (transfer u1).trans (refuted u1)
#print axioms classified
end FiveOne.Atlas6Or
