"""Overapproximate the ambient adjacency directly from raw masks and residual partners."""
from itertools import product
import json

def solve(tri,flip):
    edges=[(0,1),(0,2),(0 if tri else 3,4),(3,5)]
    color=[0,1,1,flip,1 if tri else not flip,not flip]
    pairs=[(i,j) for i in range(6) for j in range(i,6)]
    row={e:1<<k for k,e in enumerate(pairs)}
    bits=[sum(n for e,n in row.items() if i in e) for i in range(6)]
    pos=[row[e] for e in edges]
    siblings=[(x,y) for x in range(6) for y in range(x) if any(tuple(sorted((x,z))) in edges and tuple(sorted((y,z))) in edges for z in range(6))]
    menu=[m for m in range(64) if len({color[i] for i in range(6) if m>>i&1})<=1 and not any((m>>x)&(m>>y)&1 for x,y in siblings)]
    vals={m:sum(n for e,n in row.items() if any(m>>x&1 for x in e)) for m in menu}
    U={tuple(sorted(e)) for e in edges}
    allowed={m:sum(n for (p,q),n in row.items() if color[p]!=color[q] and not any(
        ((p==x and q!=y and m>>q&m>>y&1) or (q==x and p!=y and m>>p&m>>y&1))
        for e in U for x,y in (e,e[::-1]))) for m in menu}
    totals=[0]*4; cache={}; charges={}
    for ma,mb,mc,md in product(menu,repeat=4):
        d0=vals[ma]&vals[mb]; safe=allowed[ma]&allowed[mb]&allowed[mc]&allowed[md]
        for a,b in product((0,1),repeat=2):
            d1=(vals[mc]|(d0 if a else 0))&(vals[md]|(d0 if b else 0))
            key=(safe,d0,d1)
            if key not in cache:
                acc=0
                for t in [d0&d1]+[v&d for d in (d0,d1) for v in bits]:
                    if not t&~safe:acc|=t
                wins=all(acc&r for r in pos)
                needed=all(not d&row[i,i] or any(d&r and i not in e for r,e in zip(pos,edges)) for d in (d0,d1) for i in range(6))
                cnt=[max((sum(i in e and not other&r for e,r in zip(edges,pos)) for i in range(6) if d&row[i,i]),default=0) for d,other in ((d0,d1),(d1,d0))]
                cache[key]=wins,needed,cnt
            win,need,cnt=cache[key]
            totals[0]+=1
            if not win:continue
            totals[1]+=1
            if not need:continue
            totals[2]+=1
            before=any(m and d1&r and not vals[m]&r for m in (mc,md) for r in pos)
            ch=(cnt[0],cnt[1],bool(before),bool(d1&row[0,0]),tuple(bool(d0&r) for r in pos))
            charges[str(ch)]=charges.get(str(ch),0)+1
            if cnt[0]>2 or cnt[1]+int(before)>2:continue
            totals[3]+=1
    return dict(tri=tri,flip=flip,counts=totals,charges=charges)

if __name__=='__main__': print(json.dumps([solve(t,c) for t in (False,True) for c in (False,True)],indent=2))
