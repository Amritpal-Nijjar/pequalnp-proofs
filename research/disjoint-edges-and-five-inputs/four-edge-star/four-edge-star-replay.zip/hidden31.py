"""Test the unique visible signal on four positive and seven guarded negative pairs."""
from itertools import combinations_with_replacement
from functools import lru_cache
import json

edges = [(0,1),(0,2),(0,4),(3,5)]
reject = [(0,0),(3,3),(0,3),(0,5),(3,1),(3,2),(3,4)]
rows = edges+reject
table = [sum(1<<k for k,(a,b) in enumerate(rows) if m&(1<<a|1<<b)) for m in range(64)]
off = sum(1 << k for k in range(4,11))
leaves = 2+4+16
good = [m for m in range(64) if not (m&9 and m&54) and (m&leaves).bit_count()<=1]
def enumerate_menus(menus):
    count = unique = wins = 0
    example = None
    for menu in menus:
        first = {table[a]&table[b]:(a,b) for a,b in combinations_with_replacement(menu,2)}
        for d0,raw0 in first.items():
            ports = {table[m]:(m,False) for m in menu}
            for m in menu: ports.setdefault(table[m]|d0,(m,True))
            second = {a&b:(ports[a],ports[b]) for a,b in combinations_with_replacement(ports,2)}
            for d1,raw1 in second.items():
                count+=1
                if any(y==15 for y in (d0,d1,d0|d1)):
                    wins+=1
                    if example is None: example=[raw0,raw1]
    return dict(table_pairs_over_menus=count,wins=wins,example=example)
if __name__=='__main__':
    rest=sorted(set(range(64))-set(good))
    print(json.dumps(dict(base=enumerate_menus([good+[m] for m in rest]),
        binary=enumerate_menus([good+[m] for m in rest if m&leaves!=leaves]),
        siblings_only=enumerate_menus([[m for m in range(64) if m&leaves!=leaves]])),indent=2))
