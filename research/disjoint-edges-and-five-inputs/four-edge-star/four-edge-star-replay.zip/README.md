# Four residual edges and two matched edges in L-meta-17625

Amritpal-Nijjar's local research, November 26, 2026 UTC. In a bipartite four-cycle-free graph with a least binary AND/OR circuit in top form, suppose the circuit has exactly two dirty AND gates, no centerless top, and exactly two exceptional OR gates. **If the residual has four edges, every matching in the residual has at most one edge.** This rules out the previously open counts of four residual and two matched edges. The ambient graph and circuit have arbitrary size. [General matching theorem](src/FourMatching.lean) · [The desk's matching notation](src/DeskMatching.lean)

`DisconnectedFour.impossible` excludes both requested six-vertex residual shapes. With vertices A, B, C, D, E, F, the first shape has edges AB, AC, DE, DF. The second has AB, AC, AE, DF. The vertex labeling must be injective. Every physical circuit satisfying the hypotheses falls into the one-visible or both-visible case. The proof covers both. In the one-visible case, the four named edges need only be *present* in the residual. [Unified theorem](src/DisconnectedFour.lean) · [Two-star subgraph theorem](src/OneSignal.lean) · [Three-leaf star and separate edge subgraph theorem](src/TriSingle.lean)

## The one-visible case

A raw input is a vertex whose wire reaches a given wire through OR gates alone. A visible exception is the first exceptional OR on such a route from a top input through ordinary ORs, as formalized in Kapre's `ActiveOr.atTops`. For two branching centers, the previous four-edge work gives the visible gate a single raw vertex. This vertex is a retained neighbor of both centers. For a three-leaf star plus a separate edge, the current proof orients the separate edge by its retained neighbor. Every raw vertex of the visible gate must be adjacent to the star center. Bipartiteness then forces all of them to guard the same endpoint of the separate edge. Four-cycle exclusion makes that raw vertex unique.

On singleton and pair inputs avoiding that raw vertex, the visible gate is the OR of a fixed subset of the two physical dirty ANDs. Its value on four residual pairs is true. Its value on seven center-containing graph-negative rows is false. The circuit supplies the four operand masks, the earlier-to-later reachability flags, and the visible gate's reachability flags. The ambient graph may contain additional vertices and edges. [Physical signal](src/OneSignal.lean) · [Isolated-edge orientation and guarded rows](src/TriSingle.lean)

For the three-leaf star, at most one wire can have raw inputs without the ordinary retained-common-neighbor property. This exceptional wire can collect at most two of the star's leaves. Its two operands occur earlier, both have the ordinary property, and no such operand can contain two sibling leaves. An independent replay finds four passing pairs of gate truth tables, summed across mask menus, if the exceptional mask may hold all three leaves. With the binary fan-in restriction it finds zero. The Lean certificate proves the eleven-row exclusion over every permitted mask and choice of flags. [Binary fan-in proof](src/TriRaw.lean) · [Finite theorem](src/HiddenTriCert.lean) · [Control results](evidence/hidden31.json)

## The both-visible case

All four physical raw masks satisfy the retained-neighbor condition. Each mask has one bipartite color, and a port containing a residual endpoint excludes certain cross edges by four-cycle-freeness. These implications give a Boolean upper bound on ambient adjacency. Every top accepting a residual pair supplies one of five terms that accepts that pair and is safe on projected singleton and pair rows. Leastness also forces a dirty AND firing on singleton u to fire on some residual edge avoiding u. Here the hypothesis that the residual has exactly the four displayed edges is used. [Color and adjacency bounds](src/BothGeometry.lean) · [Top witnesses](src/ChartTops.lean) · [Physical projection](src/BothBridge.lean)

| Residual | Ordered choices across the two colorings | Pass positive and clean-term tests | Also pass singleton-essentiality tests | Pass all tests |
| --- | ---: | ---: | ---: | ---: |
| Two two-leaf stars | 141,508 | 338 | 0 | 0 |
| Three-leaf star and separate edge | 117,128 | 872 | 40 | 0 |

In all forty surviving choices for the second shape, the later dirty AND fires on the star center alone. The earlier dirty AND misses all three incident pairs. The physical counting theorem then requires three different later exceptional ORs, contradicting the total of two. The Python enumeration provides the counts. Lean checks the two exclusions independently using the saved LRAT proofs. [Gate-order charge](src/BothBridge.lean) · [Two-star certificate theorem](src/TwoStarCert.lean) · [Three-leaf certificate theorem](src/ThreeStarCert.lean) · [Per-color counts](evidence/probe.json)

## Why this settles the specified resource counts

Begin with two disjoint residual edges. A third edge either forms a matching of size three, joins the first two into a three-edge path, or yields a two-edge star and a separate edge. Extending the latter two configurations by a fourth distinct edge gives a triangle, a four-cycle, a matching of size three, a four-edge path, a fork, or one of the two disconnected shapes. Lean checks this classification for an arbitrary finite edge set. Bipartiteness and four-cycle-freeness handle the cycles. The previous physical proofs handle a matching of size three, the path, and the fork. The new theorems handle the disconnected shapes. [Edge classification](src/EdgeCensus.lean) · [Application to physical circuits](src/FourMatching.lean)

The only possible four-edge residual shape under these gate counts is now a star. Lean proves that all four edges share a vertex. The existence of such a least circuit remains undetermined here. The desk asks for the repeated-wire-read inequality for arbitrary residual size and gate counts under its shared-gate hypothesis. These results prove a structural subcase. No lease or public proof PR was taken for this work. [Shared-center corollary](src/RemainingGeometry.lean) · [Official step](https://pequalnp.com/desk/step?gap=L-meta-17625)

## Replay

The archive contains the 17 new modules, their prerequisite sources, and seven LRAT certificates. The module manifest identifies the dependency sources, including Sarvesh Kapre's earlier results. All 17 new modules passed a replay with solver generation disabled. [Module manifest](modules.json) · [Axiom audit](evidence/audit.txt)

Use Lean 4.36.0 and a prebuilt PEqualNP Lean project with the external imports in the manifest. The project revision `e6bfe1a56efc768d244627b78f175b18de1acd6f` contains the required project sources. From the extracted archive, run

```text
python replay.py --project PATH_TO_PROJECT/lean --toolchain PATH_TO_LEAN_4.36.0 --build-dir NEW_DIRECTORY --check-objects
```
