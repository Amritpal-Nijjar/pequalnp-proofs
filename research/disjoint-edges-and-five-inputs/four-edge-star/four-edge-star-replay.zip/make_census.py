"""Generate the two short edge-extension case tables and their Lean proofs."""
from itertools import permutations
from pathlib import Path
root=Path(__file__).resolve().parent
patterns = {
    'triangle':[(0,1),(1,2),(2,0)], 'square':[(0,1),(1,2),(2,3),(3,0)],
    'matching':[(0,1),(2,3),(4,5)], 'path':[(0,1),(1,2),(2,3),(3,4)],
    'fork':[(0,1),(0,2),(0,3),(3,4)], 'twoStars':[(0,1),(0,2),(3,4),(3,5)],
    'threeStar':[(0,1),(0,2),(0,4),(3,5)],
    'extendPath':[(0,1),(1,2),(2,3)], 'extendStar':[(0,1),(0,2),(3,4)]}
def count(p): return max(max(t) for t in p)+1
def names(p): return list('abcdef'[:count(p)])
def subs(p, labels): return [(labels[a],labels[b]) for a,b in p]
def sym(x,y): return 's('+x+','+y+')'
def tag(p): return '['+','.join(p)+'].Nodup'
head=r'''import Mathlib.Tactic
import Mathlib.Data.Sym.Sym2
namespace EdgeCensus
variable {α : Type*} [DecidableEq α]
/-- The only graph templates needed to extend two disjoint residual edges to
    four distinct simple edges. Each field is discharged from the circuit below. -/
structure Forbidden (U : Finset (Sym2 α)) : Prop where
  loop : ∀ x, s(x,x)∉U
'''
for name,p in list(patterns.items())[:7]:
    ns=names(p)
    head+=f"  {name} : ∀ {' '.join(ns)} : α, {tag(ns)} → "+' → '.join(sym(*e)+'∈U' for e in subs(p,ns))+' → False\n'
head+=r'''
theorem more {U : Finset (Sym2 α)} (card : U.card=4) (a b c : Sym2 α) :
    ∃ x y : α, s(x,y)∈U ∧ s(x,y)≠a ∧ s(x,y)≠b ∧ s(x,y)≠c := by
  classical
  let K : Finset (Sym2 α) := {a,b,c}
  have cap : K.card≤3 := by
    have t := Finset.card_insert_le a ({b,c} : Finset (Sym2 α))
    have u := Finset.card_insert_le b ({c} : Finset (Sym2 α))
    simp only [Finset.card_singleton] at u
    dsimp [K]; omega
  have omitted : ∃ e∈U, e∉K := by
    by_contra! all
    have sub : U⊆K := fun x hx => all x hx
    have bound := Finset.card_le_card sub; omega
  obtain ⟨e,mem,out⟩ := omitted
  induction e using Sym2.ind with
  | h x y =>
    exact ⟨x,y,mem,fun eq => out (by simp [K,eq]),fun eq => out (by simp [K,eq]),fun eq => out (by simp [K,eq])⟩

private theorem rev {U : Finset (Sym2 α)} {a b : α} (h : s(a,b)∈U) : s(b,a)∈U := Sym2.eq_swap ▸ h
'''
simp='[List.nodup_cons,List.mem_cons,List.not_mem_nil,or_false,List.nodup_nil,and_true,not_or]'
def extension(name,old,outputs):
    ns=names(old); es=subs(old,ns)
    out=f"\ntheorem {name} {{U : Finset (Sym2 α)}} (F : Forbidden U) (card : U.card=4) ({' '.join(ns)} : α)\n    (nd : {tag(ns)}) "
    out+=' '.join(f'(r{i} : {sym(*e)}∈U)' for i,e in enumerate(es))+' : False := by\n  classical\n'
    sy=[sym(*e) for e in es]; sy=(sy+[sy[-1]])[:3]
    out+='  obtain ⟨x,y,last,n0,n1,n2⟩ := more card '+' '.join(sy)+'\n'
    out+='  have xy : x≠y := by rintro rfl; exact F.loop _ last\n'
    out+='  simp only '+simp+' at nd\n'
    for i in range(len(es)):out+=f'  have v{i} := rev r{i}\n'
    out+='  have vLast := rev last\n'
    def leaf(x,y):
        if x==y:return 'exact F.loop _ last'
        for i,e in enumerate(es):
            if (x,y)==e:return f'exact n{i} rfl'
            if (y,x)==e:return f'exact n{i} (Sym2.eq_swap ..)'
        refs={e:f'r{i}' for i,e in enumerate(es)}
        refs.update({(b,a):f'v{i}' for i,(a,b) in enumerate(es)})
        refs[(x,y)]='last'; refs[(y,x)]='vLast'
        vs=list(dict.fromkeys(ns+[x,y]))
        for k in outputs:
            pat=patterns[k]
            for f in permutations(vs,count(pat)):
                if all(e in refs for e in subs(pat,f)):
                    target=k+' F card' if k.startswith('extend') else 'F.'+k
                    return 'exact '+target+' '+' '.join(f)+' (by simp only '+simp+'; grind only) '+' '.join(refs[e] for e in subs(pat,f))
        raise ValueError((es,x,y))
    def splity(x,indent):
        lines=[]
        for n in ns:
            lines += [indent+f'by_cases ey : y={n}',indent+'· subst y',indent+'  '+leaf(x,n)]
        lines.append(indent+leaf(x,'y'))
        return lines
    lines=[]
    for n in ns:
        lines+=['  by_cases ex : x='+n,'  · subst x',*splity(n,'    ')]
    lines+=splity('x','  ')
    # Preserve independent negative branch hypotheses when later decisions are made.
    # Lean keeps shadowed local names in its context; the equality solver reads them.
    return out+'\n'.join(lines)+'\n'
for idx in ('extendPath','extendStar'):
    head+=extension(idx,patterns[idx],list(patterns)[:7])
head+=extension('exclude',[(0,1),(2,3)],['matching','extendPath','extendStar'])
head+='\n#print axioms exclude\nend EdgeCensus\n'
(root/'src/EdgeCensus.lean').write_text(head,encoding='utf8')
